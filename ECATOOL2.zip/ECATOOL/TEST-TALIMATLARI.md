# 🧪 ECA Tool Test Talimatları

## Sorunu Tespit Etme ve Çözüm

### Adım 1: Debug Sayfasını Kullanarak Test Et

1. **Tarayıcınızda `debug.html` sayfasını açın**
2. Sayfa otomatik olarak veritabanı kontrolü yapacak
3. Konsol çıktısını inceleyin

**Beklenen Sonuç:**
```
✅ window.dbManager exists
✅ Database ready
✅ Found X assessments
✅ Found X drafts
```

### Adım 2: Test Verisi Oluştur

1. "Create Assessment" butonuna tıklayın
2. "Create 5 Assessments" butonuna tıklayın
3. "Dump All Data" butonuna tıklayarak verilerin oluşturulduğunu doğrulayın

### Adım 3: Geçmiş Sayfasını Kontrol Et

1. "Go to History Page" butonuna tıklayın
2. Tarayıcı konsolunu açın (F12)
3. Aşağıdaki logları göreceksiniz:

**Beklenen Log Çıktısı:**
```
Database initialized successfully
[HistoryManager] Loading data from database...
[HistoryManager] Loaded assessments: 5
[HistoryManager] Loaded drafts: 0
[HistoryManager] Data loaded successfully
[HistoryManager] renderCompleted called with 5 assessments
[HistoryManager] Rendering 5 assessments in card mode
```

### Adım 4: Tarayıcı Konsolunda Manuel Test

Geçmiş sayfasında F12 ile konsolu açın ve şu komutları çalıştırın:

```javascript
// 1. Database kontrolü
await window.dbReady;
console.log('DB Ready');

// 2. Kayıt sayısını kontrol et
const assessments = await window.dbManager.getAllAssessments();
console.log('Assessments:', assessments.length);

// 3. İlk kaydı göster
console.log('First assessment:', assessments[0]);

// 4. History Manager'ı kontrol et
console.log('History Manager:', window.historyManager);
console.log('Assessments in manager:', window.historyManager.assessments.length);

// 5. Manuel render dene
window.historyManager.renderCompleted();
```

## Olası Sorunlar ve Çözümleri

### Sorun 1: "window.dbManager not found"
**Çözüm:**
- `database.js` script'inin yüklendiğinden emin olun
- HTML dosyasındaki script sıralamasını kontrol edin
- database.js diğer script'lerden ÖNCE yüklenmelidir

### Sorun 2: "Database not initialized"
**Çözüm:**
- Tarayıcı konsolunda hata mesajlarını kontrol edin
- IndexedDB'nin tarayıcınızda etkin olduğundan emin olun
- Gizli mod kullanmayın
- Tarayıcı cache'ini temizleyin ve sayfayı yenileyin

### Sorun 3: "Assessments: 0 (Ama veri ekledim)"
**Çözüm:**
- `debug.html` ile veri ekleyin ve doğrulayın
- Tarayıcı Developer Tools > Application > IndexedDB > ECA_Tool_DB kontrol edin
- "assessments" store'unda veriler var mı?

### Sorun 4: "Veriler var ama görünmüyor"
**Çözüm:**
- Tarayıcı konsolunda render log'larını kontrol edin
- `renderCompleted` fonksiyonu çağrılıyor mu?
- HTML elementleri doğru yükleniyor mu?

### Sorun 5: "History Manager not initialized"
**Çözüm:**
```javascript
// Konsola şunu yazın:
if (!window.historyManager) {
    console.error('HistoryManager not found!');
    // Manuel başlatma dene:
    window.historyManager = new HistoryManager();
}
```

## Detaylı Test Senaryosu

### Test 1: Boş Veritabanı
```
1. debug.html > Clear All Data
2. history.html > "Henüz değerlendirme yok" görünmeli
3. ✅ Empty state çalışıyor
```

### Test 2: Veri Ekleme
```
1. debug.html > Create Assessment (5 kere)
2. debug.html > Dump All Data > 5 kayıt görünmeli
3. history.html > 5 kart görünmeli
4. ✅ Veri kaydediliyor
```

### Test 3: Görünüm Toggle
```
1. history.html > Kartlar görünüyor
2. "Kart/Liste" butonuna tıkla
3. Liste görünümüne geçmeli
4. Tekrar tıkla > Kart görünümü
5. ✅ Toggle çalışıyor
```

### Test 4: Gerçek Değerlendirme
```
1. assessment.html > Form doldur
2. "Sonuçları Hesapla" > results.html'e yönlendir
3. history.html > Yeni kayıt görünmeli
4. ✅ End-to-end çalışıyor
```

## Hızlı Düzeltme Komutları

Eğer hala sorun varsa, konsola şunları yazın:

### Database'i Sıfırla
```javascript
await window.dbManager.clearAll();
location.reload();
```

### Test Verisi Ekle
```javascript
const testData = {
    id: 'TEST-' + Date.now(),
    timestamp: new Date().toISOString(),
    data: {
        changeId: 'CHG-TEST',
        changeDescription: 'Test',
        changeClass: 'class2',
        changeMagnitude: 'minor'
    },
    score: 45,
    track: 'complex',
    breakdown: [],
    autoFullTrack: false
};
await window.dbManager.saveAssessment(testData);
location.reload();
```

### History Manager'ı Yeniden Başlat
```javascript
window.historyManager = new HistoryManager();
```

## Chrome DevTools ile Debug

1. F12 > Application tab
2. Storage > IndexedDB > ECA_Tool_DB
3. assessments store'u aç
4. Kayıtları manuel incele

## Log Çıktı Örnekleri

### Normal Çalışma (✅)
```
Database initialized successfully
[HistoryManager] Loading data from database...
[HistoryManager] Loaded assessments: 5
[HistoryManager] Loaded drafts: 0
[HistoryManager] Data loaded successfully
[HistoryManager] renderCompleted called with 5 assessments
[HistoryManager] Rendering 5 assessments in card mode
```

### Sorunlu Çalışma (❌)
```
Database initialization error: ...
[HistoryManager] Error loading data: ...
```

veya

```
[HistoryManager] Loaded assessments: 0
[HistoryManager] No data, showing empty state
```

## İletişim

Eğer sorun devam ederse:
1. Tarayıcı konsol çıktısının ekran görüntüsünü alın
2. `debug.html` sonuçlarının ekran görüntüsünü alın
3. Hangi adımda sorun oluştu?
4. Tarayıcı ve versiyon bilgisi

---

**Önemli**: Tüm test adımlarını sırayla yapın ve her adımın sonucunu not edin!
