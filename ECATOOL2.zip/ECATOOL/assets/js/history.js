/**
 * History and Drafts Management
 * View, search, export, and manage assessments
 */

class HistoryManager {
    constructor() {
        this.currentTab = 'completed';
        this.assessments = [];
        this.drafts = [];
        this.currentDeleteId = null;
        this.init();
    }

    async init() {
        this.viewMode = 'card'; // 'card' veya 'list'
        this.selectedIds = new Set(); // For bulk delete
        await this.loadData();
        this.setupTabs();
        this.setupSearch();
        this.setupActions();
        this.setupViewToggle();
        this.setupBulkActions();
        this.renderCompleted();
        this.renderDrafts();
    }

    setupViewToggle() {
        const toggleBtn = document.getElementById('toggleViewBtn');
        if (toggleBtn) {
            toggleBtn.addEventListener('click', () => {
                this.viewMode = this.viewMode === 'card' ? 'list' : 'card';
                this.renderCompleted();
            });
        }
    }

    async loadData() {
        try {
            console.log('[HistoryManager] Loading data from database...');
            this.assessments = await window.dbManager.getAllAssessments();
            console.log('[HistoryManager] Loaded assessments:', this.assessments.length);
            this.drafts = await window.dbManager.getAllDrafts();
            console.log('[HistoryManager] Loaded drafts:', this.drafts.length);
            this.updateCounts();
            console.log('[HistoryManager] Data loaded successfully');
        } catch (error) {
            console.error('[HistoryManager] Error loading data:', error);
            this.assessments = [];
            this.drafts = [];
        }
    }

    updateCounts() {
        document.getElementById('completedCount').textContent = this.assessments.length;
        document.getElementById('draftsCount').textContent = this.drafts.length;
    }

    setupTabs() {
        document.querySelectorAll('.history-tabs .tab-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const tab = btn.dataset.tab;
                this.switchTab(tab);
            });
        });
    }

    switchTab(tab) {
        this.currentTab = tab;

        // Update tab buttons
        document.querySelectorAll('.history-tabs .tab-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tab === tab);
        });

        // Update tab content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.toggle('active', content.dataset.tab === tab);
        });
    }

    setupSearch() {
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.addEventListener('input', debounce((e) => {
                this.searchAssessments(e.target.value);
            }, 300));
        }
    }

    searchAssessments(query) {
        const filtered = this.assessments.filter(a => {
            const searchStr = `${a.id} ${a.data.changeId} ${a.data.changeDescription}`.toLowerCase();
            return searchStr.includes(query.toLowerCase());
        });

        this.renderCompleted(filtered);
    }

    setupActions() {
        // Export All
        const exportAllBtn = document.getElementById('exportAllBtn');
        if (exportAllBtn) {
            exportAllBtn.addEventListener('click', () => this.exportAll());
        }

        // Import CSV
        const importBtn = document.getElementById('importCsvBtn');
        const fileInput = document.getElementById('csvFileInput');

        if (importBtn && fileInput) {
            importBtn.addEventListener('click', () => fileInput.click());
            fileInput.addEventListener('change', (e) => this.importCsv(e));
        }
    }

    renderCompleted(data = this.assessments) {
        console.log('[HistoryManager] renderCompleted called with', data.length, 'assessments');
        const cardsGrid = document.getElementById('completedCardsGrid');
        const listGrid = document.getElementById('completedListGrid');
        const emptyState = document.getElementById('completedEmpty');

        if (data.length === 0) {
            console.log('[HistoryManager] No data, showing empty state');
            cardsGrid.innerHTML = '';
            listGrid.innerHTML = '';
            emptyState.style.display = 'block';
            cardsGrid.style.display = '';
            listGrid.style.display = 'none';
            return;
        }

        console.log('[HistoryManager] Rendering', data.length, 'assessments in', this.viewMode, 'mode');
        emptyState.style.display = 'none';

        // Sort by date (newest first)
        const sorted = [...data].sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

        if (this.viewMode === 'card') {
            cardsGrid.style.display = '';
            listGrid.style.display = 'none';
            cardsGrid.innerHTML = sorted.map(assessment => {
                const circumference = 2 * Math.PI * 27;
                const offset = circumference - (assessment.score / 100) * circumference;
                const isSelected = this.selectedIds.has(assessment.id);
                return `
                <div class="assessment-card">
                    <div class="assessment-card-header">
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <input type="checkbox" class="assessment-checkbox" ${isSelected ? 'checked' : ''}
                                   onchange="window.historyManager.toggleSelection('${assessment.id}')" />
                            <div class="assessment-card-id">${escapeHtml(assessment.data.changeId || assessment.id)}</div>
                        </div>
                        <div class="assessment-card-date">${formatDate(assessment.timestamp)}</div>
                    </div>
                    <div class="assessment-card-description">${escapeHtml(assessment.data.changeDescription || '-')}</div>
                    <div class="assessment-card-score">
                        <div class="score-circle-mini">
                            <svg viewBox="0 0 60 60">
                                <circle class="score-bg" cx="30" cy="30" r="27" stroke-dasharray="${circumference}" stroke-dashoffset="0"/>
                                <circle class="score-progress" cx="30" cy="30" r="27" stroke-dasharray="${circumference}" stroke-dashoffset="${offset}"/>
                            </svg>
                            <div class="score-text">${assessment.score}</div>
                        </div>
                        <div class="score-info">
                            <div class="score-label">Önerilen Track</div>
                            <div class="score-track ${assessment.track}">
                                ${assessment.track === 'simple' ? 'Fast-Track Simple' : assessment.track === 'complex' ? 'Fast-Track Complex' : 'Full-Track'}
                            </div>
                        </div>
                    </div>
                    <div class="assessment-card-actions">
                        <button class="card-action-btn" onclick="window.historyManager.viewAssessment('${assessment.id}')" title="Görüntüle">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                                <circle cx="12" cy="12" r="3"/>
                            </svg>
                            Görüntüle
                        </button>
                        <button class="card-action-btn" onclick="window.historyManager.exportSingle('${assessment.id}')" title="CSV Export">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/>
                                <polyline points="7 10 12 15 17 10"/>
                                <line x1="12" y1="15" x2="12" y2="3"/>
                            </svg>
                            CSV
                        </button>
                        <button class="card-action-btn" onclick="window.historyManager.showMailPreview('${assessment.id}')" title="Mail Önizleme">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                                <polyline points="22,6 12,13 2,6"/>
                            </svg>
                            Mail
                        </button>
                        <button class="card-action-btn danger" onclick="window.historyManager.deleteAssessment('${assessment.id}')" title="Sil">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="3 6 5 6 21 6"/>
                                <path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/>
                            </svg>
                            Sil
                        </button>
                    </div>
                </div>
            `}).join('');
        } else {
            // Liste görünümü
            cardsGrid.style.display = 'none';
            listGrid.style.display = '';
            listGrid.innerHTML = `
                <table class="history-list-table">
                    <thead>
                        <tr>
                            <th><input type="checkbox" onchange="window.historyManager.toggleSelectAll()" /></th>
                            <th>ID</th>
                            <th>Açıklama</th>
                            <th>Tarih</th>
                            <th>Puan</th>
                            <th>Track</th>
                            <th>İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${sorted.map(assessment => {
                            const isSelected = this.selectedIds.has(assessment.id);
                            return `
                            <tr>
                                <td data-label="Seç"><input type="checkbox" class="assessment-checkbox" ${isSelected ? 'checked' : ''}
                                                            onchange="window.historyManager.toggleSelection('${assessment.id}')" /></td>
                                <td data-label="ID">${escapeHtml(assessment.data.changeId || assessment.id)}</td>
                                <td data-label="Açıklama">${escapeHtml(assessment.data.changeDescription || '-')}</td>
                                <td data-label="Tarih">${formatDate(assessment.timestamp)}</td>
                                <td data-label="Puan">${assessment.score}</td>
                                <td data-label="Track">${assessment.track === 'simple' ? 'Fast-Track Simple' : assessment.track === 'complex' ? 'Fast-Track Complex' : 'Full-Track'}</td>
                                <td data-label="İşlemler">
                                    <button class="card-action-btn" onclick="window.historyManager.viewAssessment('${assessment.id}')" title="Görüntüle">Görüntüle</button>
                                    <button class="card-action-btn" onclick="window.historyManager.exportSingle('${assessment.id}')" title="CSV Export">CSV</button>
                                    <button class="card-action-btn" onclick="window.historyManager.showMailPreview('${assessment.id}')" title="Mail Önizleme">Mail</button>
                                    <button class="card-action-btn danger" onclick="window.historyManager.deleteAssessment('${assessment.id}')" title="Sil">Sil</button>
                                </td>
                            </tr>
                        `;
                        }).join('')}
                    </tbody>
                </table>
            `;
        }
    }

    getTrackBadge(track) {
        const badges = {
            simple: '<span class="badge" style="background: #d4edda; color: #218838; padding: 4px 12px; border-radius: 12px; font-size: 0.75rem; font-weight: 600;">Fast-Track Simple</span>',
            complex: '<span class="badge" style="background: #fff3cd; color: #856404; padding: 4px 12px; border-radius: 12px; font-size: 0.75rem; font-weight: 600;">Fast-Track Complex</span>',
            full: '<span class="badge" style="background: #f8d7da; color: #b71c1c; padding: 4px 12px; border-radius: 12px; font-size: 0.75rem; font-weight: 600;">Full-Track</span>'
        };
        return badges[track] || '';
    }

    renderDrafts() {
        const grid = document.getElementById('draftsGrid');
        const emptyState = document.getElementById('draftsEmpty');

        if (this.drafts.length === 0) {
            grid.innerHTML = '';
            emptyState.style.display = 'block';
            return;
        }

        emptyState.style.display = 'none';

        // Sort by timestamp (newest first)
        const sorted = [...this.drafts].sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

        grid.innerHTML = sorted.map(draft => `
            <div class="draft-card">
                <div class="draft-badge">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M12 20h9"/>
                        <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/>
                    </svg>
                    Taslak
                </div>
                <div class="assessment-card-header">
                    <div class="assessment-card-id">${escapeHtml(draft.data.changeId || 'ID Girilmedi')}</div>
                    <div class="assessment-card-date">${getRelativeTime(draft.timestamp)}</div>
                </div>
                <div class="assessment-card-description">${escapeHtml(draft.data.changeDescription || 'Açıklama henüz girilmedi')}</div>
                <div class="assessment-card-actions">
                    <button class="card-action-btn" onclick="window.historyManager.continueDraft('${draft.id}')">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polygon points="5 3 19 12 5 21 5 3"/>
                        </svg>
                        Devam Et
                    </button>
                    <button class="card-action-btn danger" onclick="window.historyManager.deleteDraft('${draft.id}')">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="3 6 5 6 21 6"/>
                            <path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/>
                        </svg>
                        Sil
                    </button>
                </div>
            </div>
        `).join('');
    }

    viewAssessment(id) {
        window.location.href = `results.html?id=${id}`;
    }

    exportSingle(id) {
        const assessment = this.assessments.find(a => a.id === id);
        if (!assessment) return;

        const data = [{
            'Değişiklik ID': assessment.data.changeId || assessment.id,
            'Açıklama': assessment.data.changeDescription || '',
            'Tarih': formatDate(assessment.timestamp),
            'Puan': assessment.score,
            'Öneri': assessment.track === 'simple' ? 'Fast-Track Simple' : assessment.track === 'complex' ? 'Fast-Track Complex' : 'Full-Track',
            'Sınıf': assessment.data.changeClass === 'class1' ? 'Sınıf 1' : 'Sınıf 2',
            'Büyüklük': assessment.data.changeMagnitude === 'major' ? 'Major' : 'Minor'
        }];

        exportToCsv(data, `assessment-${assessment.id}.csv`);
    }

    exportAll() {
        if (this.assessments.length === 0) {
            showToast('warning', 'Uyarı', 'Dışa aktarılacak değerlendirme bulunamadı');
            return;
        }

        const data = this.assessments.map(a => ({
            'Değişiklik ID': a.data.changeId || a.id,
            'Açıklama': a.data.changeDescription || '',
            'Tarih': formatDate(a.timestamp),
            'Puan': a.score,
            'Öneri': a.track === 'simple' ? 'Fast-Track Simple' : a.track === 'complex' ? 'Fast-Track Complex' : 'Full-Track',
            'Sınıf': a.data.changeClass === 'class1' ? 'Sınıf 1' : 'Sınıf 2',
            'Büyüklük': a.data.changeMagnitude === 'major' ? 'Major' : 'Minor',
            'Müşteri Talebi': a.data.customerRequest === 'yes' ? 'Evet' : 'Hayır'
        }));

        exportToCsv(data, `eca-assessments-${new Date().toISOString().split('T')[0]}.csv`);
    }

    importCsv(e) {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (event) => {
            try {
                const csvData = parseCsv(event.target.result);
                // Process and validate CSV data
                showToast('success', 'Başarılı', `${csvData.length} kayıt içe aktarıldı`);
                this.loadData();
                this.renderCompleted();
            } catch (error) {
                showToast('error', 'Hata', 'CSV dosyası işlenirken hata oluştu');
                console.error('CSV Import Error:', error);
            }
        };
        reader.readAsText(file);
        e.target.value = ''; // Reset input
    }

    showMailPreview(id) {
        const assessment = this.assessments.find(a => a.id === id);
        if (!assessment) return;

        const modal = document.getElementById('mailPreviewModal');
        const content = document.getElementById('mailPreviewContent');

        content.innerHTML = generateEmailHtml(assessment);

        modal.classList.add('show');

        // Copy HTML button
        document.getElementById('copyEmailHtml').onclick = () => {
            copyToClipboard(content.innerHTML);
        };

        // Open Outlook button
        document.getElementById('openMailto').onclick = () => {
            const trackLabel = assessment.track === 'simple' ? 'Fast-Track Simple' : assessment.track === 'complex' ? 'Fast-Track Complex' : 'Full-Track';
            const classLabel = assessment.data.changeClass === 'class1' ? 'Sınıf 1' : 'Sınıf 2';
            const magnitudeLabel = assessment.data.changeMagnitude === 'major' ? 'Major' : 'Minor';
            const customerRequestLabel = assessment.data.customerRequest === 'yes' ? 'Evet' : 'Hayır';

            const subject = `ECA Tool Değerlendirme Sonucu: ${assessment.data.changeId || 'Değerlendirme'}`;

            let body = `══════════════════════════════════════════\n`;
            body += `       ECA TOOL DEĞERLENDİRME SONUCU\n`;
            body += `══════════════════════════════════════════\n\n`;

            body += `📊 GENEL BİLGİLER\n`;
            body += `──────────────────────────────────────────\n`;
            body += `Değişiklik ID    : ${assessment.data.changeId || '-'}\n`;
            body += `Açıklama         : ${assessment.data.changeDescription || '-'}\n`;
            body += `Değerlendirme    : ${formatDate(assessment.timestamp)}\n\n`;

            body += `📈 SONUÇ\n`;
            body += `──────────────────────────────────────────\n`;
            body += `Risk Puanı       : ${assessment.score} / 100\n`;
            body += `Önerilen Track   : ${trackLabel}\n\n`;

            body += `📋 DEĞİŞİKLİK DETAYLARI\n`;
            body += `──────────────────────────────────────────\n`;
            body += `Değişiklik Sınıfı: ${classLabel}\n`;
            body += `Büyüklük         : ${magnitudeLabel}\n`;
            body += `Müşteri Talebi   : ${customerRequestLabel}\n`;

            if (assessment.data.affectedAreas && assessment.data.affectedAreas.length > 0) {
                body += `Etkilenen Alanlar: ${assessment.data.affectedAreas.join(', ')}\n`;
            }

            if (assessment.autoFullTrack) {
                body += `\n⚠️ OTOMATİK FULL-TRACK\n`;
                body += `──────────────────────────────────────────\n`;
                body += `Neden: ${assessment.autoFullTrackReason}\n`;
            }

            body += `\n══════════════════════════════════════════\n`;
            body += `Bu e-posta ECA Tool tarafından otomatik oluşturulmuştur.\n`;
            body += `══════════════════════════════════════════`;

            window.location.href = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
        };
    }

    deleteAssessment(id) {
        this.currentDeleteId = id;
        const modal = document.getElementById('deleteModal');
        modal.classList.add('show');

        document.getElementById('confirmDeleteBtn').onclick = () => {
            this.confirmDelete();
        };
    }

    async confirmDelete() {
        if (!this.currentDeleteId) return;

        try {
            await window.dbManager.deleteAssessment(this.currentDeleteId);
            showToast('success', 'Silindi', 'Değerlendirme başarıyla silindi');

            await this.loadData();
            this.renderCompleted();
            this.closeDeleteModal();
        } catch (error) {
            console.error('Error deleting assessment:', error);
            showToast('error', 'Hata', 'Silme işlemi başarısız');
        }
    }

    closeDeleteModal() {
        document.getElementById('deleteModal').classList.remove('show');
        this.currentDeleteId = null;
    }

    continueDraft(id) {
        window.location.href = `assessment.html?draft=${id}`;
    }

    async deleteDraft(id) {
        if (confirm('Bu taslağı silmek istediğinizden emin misiniz?')) {
            try {
                await window.dbManager.deleteDraft(id);
                showToast('success', 'Silindi', 'Taslak başarıyla silindi');
                await this.loadData();
                this.renderDrafts();
            } catch (error) {
                console.error('Error deleting draft:', error);
                showToast('error', 'Hata', 'Silme işlemi başarısız');
            }
        }
    }

    setupBulkActions() {
        // Bulk delete functionality
        const bulkDeleteBtn = document.getElementById('bulkDeleteBtn');
        const selectAllBtn = document.getElementById('selectAllBtn');

        if (selectAllBtn) {
            selectAllBtn.addEventListener('click', () => this.toggleSelectAll());
        }

        if (bulkDeleteBtn) {
            bulkDeleteBtn.addEventListener('click', () => this.bulkDelete());
        }
    }

    toggleSelectAll() {
        const checkboxes = document.querySelectorAll('.assessment-checkbox');
        const allSelected = this.selectedIds.size === this.assessments.length;

        if (allSelected) {
            this.selectedIds.clear();
            checkboxes.forEach(cb => cb.checked = false);
        } else {
            this.assessments.forEach(a => this.selectedIds.add(a.id));
            checkboxes.forEach(cb => cb.checked = true);
        }

        this.updateBulkActionButtons();
    }

    async bulkDelete() {
        if (this.selectedIds.size === 0) {
            showToast('warning', 'Uyarı', 'Lütfen silinecek kayıtları seçin');
            return;
        }

        if (!confirm(`${this.selectedIds.size} kayıt silinecek. Emin misiniz?`)) {
            return;
        }

        try {
            await window.dbManager.deleteAssessments(Array.from(this.selectedIds));
            showToast('success', 'Silindi', `${this.selectedIds.size} kayıt başarıyla silindi`);
            this.selectedIds.clear();
            await this.loadData();
            this.renderCompleted();
        } catch (error) {
            console.error('Error bulk deleting:', error);
            showToast('error', 'Hata', 'Toplu silme işlemi başarısız');
        }
    }

    toggleSelection(id) {
        if (this.selectedIds.has(id)) {
            this.selectedIds.delete(id);
        } else {
            this.selectedIds.add(id);
        }
        this.updateBulkActionButtons();
    }

    updateBulkActionButtons() {
        const bulkDeleteBtn = document.getElementById('bulkDeleteBtn');
        if (bulkDeleteBtn) {
            bulkDeleteBtn.disabled = this.selectedIds.size === 0;
            bulkDeleteBtn.textContent = this.selectedIds.size > 0
                ? `Seçilenleri Sil (${this.selectedIds.size})`
                : 'Seçilenleri Sil';
        }
    }
}

// Global functions for onclick handlers
function closeMailModal() {
    const modal = document.getElementById('mailPreviewModal');
    modal.classList.remove('show');
    // Modal içeriğini temizle (DOM bozulmasını önle)
    const content = document.getElementById('mailPreviewContent');
    if (content) {
        content.innerHTML = '';
    }
}

function closeDeleteModal() {
    if (window.historyManager) {
        window.historyManager.closeDeleteModal();
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', async () => {
    // Wait for database to be ready
    try {
        await window.dbReady;
        window.historyManager = new HistoryManager();
    } catch (error) {
        console.error('Failed to initialize history manager:', error);
        showToast('error', 'Hata', 'Uygulama başlatılamadı. Lütfen sayfayı yenileyin.');
    }
});
