/**
 * ECA Tool - Assessment Engine
 * Comprehensive scoring algorithm with 12 criteria evaluation
 */

class AssessmentEngine {
    constructor() {
        this.currentStage = 1;
        this.formData = {};
        this.autoSaveInterval = null;
        this.init();
    }

    init() {
        this.loadDraftOrDemo();
        this.attachEventListeners();
        this.startAutoSave();
        this.updateProgress();
        this.calculateScore();
    }

    loadDraftOrDemo() {
        // Check for draft from URL
        const urlParams = new URLSearchParams(window.location.search);
        const draftId = urlParams.get('draft');
        const demoId = urlParams.get('demo');

        if (draftId) {
            this.loadDraft(draftId);
        } else if (demoId) {
            this.loadDemo();
        }
    }

    async loadDraft(draftId) {
        try {
            const draft = await window.dbManager.getDraft(draftId);

            if (draft) {
                this.formData = draft.data;
                this.populateForm(draft.data);
                showToast('success', 'Taslak Yüklendi', 'Taslak başarıyla yüklendi');
            }
        } catch (error) {
            console.error('Error loading draft:', error);
        }
    }

    loadDemo() {
        const demoData = localStorage.getItem('demoScenario');
        if (demoData) {
            this.formData = JSON.parse(demoData);
            this.populateForm(this.formData);
            localStorage.removeItem('demoScenario');
            showToast('info', 'Demo Yüklendi', 'Demo senaryo yüklendi');
        }
    }

    populateForm(data) {
        Object.keys(data).forEach(key => {
            const input = document.querySelector(`[name="${key}"]`);
            if (input) {
                if (input.type === 'radio') {
                    const radio = document.querySelector(`[name="${key}"][value="${data[key]}"]`);
                    if (radio) radio.checked = true;
                } else {
                    input.value = data[key];
                }
            }
        });
        this.updateProgress();
        this.calculateScore();
    }

    attachEventListeners() {
        const form = document.getElementById('assessmentForm');

        // Form input listeners
        form.addEventListener('input', (e) => {
            this.handleInputChange(e);
        });

        // Radio toggle (click to deselect)
        form.querySelectorAll('input[type="radio"]').forEach(radio => {
            radio.addEventListener('click', (e) => {
                if (radio.dataset.wasChecked === 'true') {
                    radio.checked = false;
                    radio.dataset.wasChecked = 'false';
                    delete this.formData[radio.name];
                    this.calculateScore();
                    this.updateProgress();
                } else {
                    form.querySelectorAll(`input[name="${radio.name}"]`).forEach(r => {
                        r.dataset.wasChecked = 'false';
                    });
                    radio.dataset.wasChecked = 'true';
                }
            });
        });

        // Navigation buttons
        document.getElementById('nextBtn').addEventListener('click', () => this.nextStage());
        document.getElementById('prevBtn')?.addEventListener('click', () => this.prevStage());
        document.getElementById('saveDraftBtn').addEventListener('click', () => this.saveDraft());

        // Tab buttons
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                if (!btn.disabled) {
                    const stage = parseInt(btn.dataset.stage);
                    this.goToStage(stage);
                }
            });
        });

        // Form submission
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            this.submitAssessment();
        });

        // Auth is no longer required for Stage 2
    }

    handleInputChange(e) {
        const { name, value, type } = e.target;

        if (type === 'radio') {
            this.formData[name] = value;
        } else {
            this.formData[name] = value;
        }

        this.calculateScore();
        this.updateProgress();
    }


    calculateScore() {
        let totalScore = 0;
        let breakdown = [];
        let autoFullTrack = false;
        let autoFullTrackReason = '';

        // 1. Change Class (10 or 5 points)
        if (this.formData.changeClass === 'class1') {
            totalScore += 10;
            breakdown.push({ label: 'Değişiklik Sınıfı', points: 10, max: 10 });
            autoFullTrack = true;
            autoFullTrackReason = 'Sınıf 1 değişiklik';
        } else if (this.formData.changeClass === 'class2') {
            totalScore += 5;
            breakdown.push({ label: 'Değişiklik Sınıfı', points: 5, max: 10 });
        }

        // 2. Change Magnitude (2-5 points)
        if (this.formData.changeMagnitude === 'minor') {
            totalScore += 2;
            breakdown.push({ label: 'Değişiklik Büyüklüğü', points: 2, max: 5 });
        } else if (this.formData.changeMagnitude === 'major') {
            totalScore += 5;
            breakdown.push({ label: 'Değişiklik Büyüklüğü', points: 5, max: 5 });
        }

        // 3. Customer Request (Auto Full-Track trigger)
        if (this.formData.customerRequest === 'yes') {
            autoFullTrack = true;
            autoFullTrackReason = 'Müşteri talebi';
        }

        // 4. Delivery Impact (0-10 points)
        const deliveryPoints = {
            'no': 0,
            'minor': 3,
            'moderate': 6,
            'significant': 10
        };
        if (this.formData.deliveryImpact) {
            const points = deliveryPoints[this.formData.deliveryImpact];
            totalScore += points;
            breakdown.push({ label: 'Teslimata Etkisi', points, max: 10 });

            if (this.formData.deliveryImpact === 'significant') {
                autoFullTrack = true;
                autoFullTrackReason = 'Önemli teslimat gecikmesi';
            }
        }

        // 5. Test Infrastructure (2-5 points)
        const testInfraPoints = {
            'no': 2,
            'minor': 3,
            'major': 5
        };
        if (this.formData.testInfra) {
            const points = testInfraPoints[this.formData.testInfra];
            totalScore += points;
            breakdown.push({ label: 'Test Altyapısı', points, max: 5 });
        }

        // 6. Production Infrastructure (2-5 points)
        const prodInfraPoints = {
            'no': 2,
            'minor': 3,
            'major': 5
        };
        if (this.formData.prodInfra) {
            const points = prodInfraPoints[this.formData.prodInfra];
            totalScore += points;
            breakdown.push({ label: 'Üretim Altyapısı', points, max: 5 });
        }

        // Stage 2 criteria (only if filled)
        if (this.currentStage >= 2 || Object.keys(this.formData).some(k => k.startsWith('just'))) {
            // 7. Justification Matrix (0-15 points with 1.5x multiplier)
            let matrixScore = 0;
            const matrixFields = ['justDoc', 'justDesign', 'justProduction', 'justStock', 'justPart', 'justMarket', 'justOther'];

            matrixFields.forEach(field => {
                if (this.formData[field]) {
                    const points = parseInt(this.formData[field]);
                    matrixScore += points;

                    // Check for critical combinations
                    if ((field === 'justProduction' && points === 10) || (field === 'justDesign' && points === 7)) {
                        if (this.formData.customerDoc === 'major' || this.formData.sideEffect === 'major') {
                            autoFullTrack = true;
                            autoFullTrackReason = 'Kritik gerekçe + müşteri etkisi';
                        }
                    }
                }
            });

            const matrixFinal = Math.round(matrixScore * 1.5);
            totalScore += matrixFinal;
            breakdown.push({ label: 'Gerekçe Matrisi (1.5x)', points: matrixFinal, max: 15 });

            // 8. Project Count (0-5 points)
            const projectPoints = {
                '1': 0,
                '2-4': 3,
                '5+': 5
            };
            if (this.formData.projectCount) {
                const points = projectPoints[this.formData.projectCount];
                totalScore += points;
                breakdown.push({ label: 'Etkilenen Proje', points, max: 5 });

                if (this.formData.projectCount === '5+') {
                    autoFullTrack = true;
                    autoFullTrackReason = '5+ proje etkisi';
                }
            }

            // 9. Side Effect (1-3 points)
            const sideEffectPoints = {
                'no': 1,
                'minor': 2,
                'major': 3
            };
            if (this.formData.sideEffect) {
                const points = sideEffectPoints[this.formData.sideEffect];
                totalScore += points;
                breakdown.push({ label: 'Yan Sistem Etkisi', points, max: 3 });
            }

            // 10. Customer Document (1-5 points)
            const customerDocPoints = {
                'no': 1,
                'minor': 3,
                'major': 5
            };
            if (this.formData.customerDoc) {
                const points = customerDocPoints[this.formData.customerDoc];
                totalScore += points;
                breakdown.push({ label: 'Müşteri Dokümanı', points, max: 5 });
            }

            // 11. DK Delivery (2-10 points)
            const dkDeliveryPoints = {
                'no': 2,
                'minor': 5,
                'moderate': 7,
                'major': 10
            };
            if (this.formData.dkDelivery) {
                const points = dkDeliveryPoints[this.formData.dkDelivery];
                totalScore += points;
                breakdown.push({ label: 'DK Teslimat', points, max: 10 });
            }

            // 12. Open Order (0-5 points)
            const openOrderPoints = {
                'no': 0,
                'minor': 3,
                'major': 5
            };
            if (this.formData.openOrder) {
                const points = openOrderPoints[this.formData.openOrder];
                totalScore += points;
                breakdown.push({ label: 'Açık Sipariş', points, max: 5 });

                // Check for critical combination
                if (points >= 3 && matrixScore >= 7) {
                    autoFullTrack = true;
                    autoFullTrackReason = 'Açık sipariş + kritik gerekçe';
                }
            }

            // 13. Purchase Order (0-5 points)
            const purchaseOrderPoints = {
                'no': 0,
                'minor': 3,
                'major': 5
            };
            if (this.formData.purchaseOrder) {
                const points = purchaseOrderPoints[this.formData.purchaseOrder];
                totalScore += points;
                breakdown.push({ label: 'Üretim/Satın Alma', points, max: 5 });
            }
        }

        // Determine track recommendation
        let track, trackClass, trackLabel;
        if (autoFullTrack) {
            track = 'full';
            trackClass = 'track-badge-full';
            trackLabel = `Full-Track (${autoFullTrackReason})`;
        } else if (totalScore >= 70) {
            track = 'full';
            trackClass = 'track-badge-full';
            trackLabel = 'Full-Track';
        } else if (totalScore >= 40) {
            track = 'complex';
            trackClass = 'track-badge-complex';
            trackLabel = 'Fast-Track Complex';
        } else {
            track = 'simple';
            trackClass = 'track-badge-simple';
            trackLabel = 'Fast-Track Simple';
        }

        // Update UI
        document.getElementById('liveScore').textContent = totalScore;
        const trackElement = document.getElementById('liveTrack');
        trackElement.innerHTML = `<div class="track-badge ${trackClass}">${trackLabel}</div>`;

        // Update breakdown
        const breakdownElement = document.getElementById('scoreBreakdown');
        if (breakdown.length > 0) {
            breakdownElement.innerHTML = breakdown.map(item =>
                `<div style="font-size: 0.75rem; opacity: 0.9;">${item.label}: ${item.points}/${item.max}</div>`
            ).join('');
        }

        return { totalScore, track, breakdown, autoFullTrack, autoFullTrackReason };
    }

    updateProgress() {
        const requiredFields = this.getRequiredFieldsForStage(this.currentStage);
        const filledFields = requiredFields.filter(field => this.formData[field]);
        const progress = Math.round((filledFields.length / requiredFields.length) * 100);

        document.getElementById('progressPercent').textContent = `${progress}%`;
        document.getElementById('progressBar').style.width = `${progress}%`;
        document.getElementById('progressLabel').textContent = `Aşama ${this.currentStage} / 2`;
    }

    getRequiredFieldsForStage(stage) {
        if (stage === 1) {
            return ['changeId', 'changeClass', 'changeMagnitude', 'deliveryImpact', 'testInfra', 'prodInfra'];
        } else {
            return ['projectCount', 'dkDelivery'];
        }
    }

    validateStage(stage, silent = false) {
        const requiredFields = this.getRequiredFieldsForStage(stage);
        const missingFields = requiredFields.filter(field => !this.formData[field]);

        if (missingFields.length > 0) {
            if (!silent) {
                showToast('error', 'Eksik Alanlar', 'Lütfen tüm gerekli alanları doldurun');
            }
            return false;
        }

        return true;
    }

    nextStage() {
        if (this.currentStage === 1) {
            if (!this.validateStage(1)) return;

            this.saveDraft(true); // Auto-save before proceeding
            this.goToStage(2);
        }
    }

    prevStage() {
        if (this.currentStage > 1) {
            this.goToStage(this.currentStage - 1);
        }
    }

    goToStage(stage) {
        // Hide all stages
        document.querySelectorAll('.form-stage').forEach(s => s.classList.remove('active'));

        // Show target stage
        const targetStage = document.querySelector(`.form-stage[data-stage="${stage}"]`);
        if (targetStage) {
            targetStage.classList.add('active');
        }

        // Update tabs
        document.querySelectorAll('.tab-btn').forEach(btn => {
            const btnStage = parseInt(btn.dataset.stage);
            btn.classList.toggle('active', btnStage === stage);
        });

        // Update navigation buttons
        const prevBtn = document.getElementById('prevBtn');
        const nextBtn = document.getElementById('nextBtn');
        const submitBtn = document.getElementById('submitBtn');

        if (stage === 1) {
            prevBtn.style.display = 'none';
            nextBtn.style.display = 'inline-flex';
            submitBtn.style.display = 'none';
        } else {
            prevBtn.style.display = 'inline-flex';
            nextBtn.style.display = 'none';
            submitBtn.style.display = 'inline-flex';
        }

        this.currentStage = stage;
        this.updateProgress();
    }

    async saveDraft(silent = false) {
        if (!this.formData.changeId && !silent) {
            showToast('error', 'Hata', 'En az Değişiklik ID girilmelidir');
            return;
        }

        const draftId = this.formData.changeId || `draft-${Date.now()}`;
        const draft = {
            id: draftId,
            data: this.formData,
            timestamp: new Date().toISOString(),
            stage: this.currentStage
        };

        try {
            await window.dbManager.saveDraft(draft);

            if (!silent) {
                showToast('success', 'Taslak Kaydedildi', 'Değerlendirme taslak olarak kaydedildi');
                this.showAutoSaveIndicator();
            }
        } catch (error) {
            console.error('Error saving draft:', error);
            if (!silent) {
                showToast('error', 'Hata', 'Taslak kaydedilemedi');
            }
        }
    }

    showAutoSaveIndicator() {
        const indicator = document.getElementById('autosaveIndicator');
        indicator.classList.add('show');
        setTimeout(() => {
            indicator.classList.remove('show');
        }, 2000);
    }

    startAutoSave() {
        // Auto-save every 30 seconds
        this.autoSaveInterval = setInterval(() => {
            if (Object.keys(this.formData).length > 0) {
                this.saveDraft(true);
                this.showAutoSaveIndicator();
            }
        }, 30000);
    }

    async submitAssessment() {
        if (!this.validateStage(2)) return;

        const result = this.calculateScore();
        const assessment = {
            id: this.formData.changeId || `ASM-${Date.now()}`,
            timestamp: new Date().toISOString(),
            data: this.formData,
            score: result.totalScore,
            track: result.track,
            breakdown: result.breakdown,
            autoFullTrack: result.autoFullTrack,
            autoFullTrackReason: result.autoFullTrackReason
        };

        try {
            // Save to IndexedDB
            await window.dbManager.saveAssessment(assessment);

            // Remove draft from IndexedDB
            try {
                await window.dbManager.deleteDraft(this.formData.changeId);
            } catch (e) {
                // Draft might not exist, ignore error
            }

            // Show success and redirect
            showToast('success', 'Değerlendirme Tamamlandı', 'Sonuçlar sayfasına yönlendiriliyorsunuz...');

            setTimeout(() => {
                window.location.href = `results.html?id=${assessment.id}`;
            }, 1500);
        } catch (error) {
            console.error('Error saving assessment:', error);
            showToast('error', 'Hata', 'Değerlendirme kaydedilemedi');
        }
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', async () => {
    // Wait for database to be ready
    try {
        await window.dbReady;
        window.assessmentEngine = new AssessmentEngine();
    } catch (error) {
        console.error('Failed to initialize assessment engine:', error);
        showToast('error', 'Hata', 'Uygulama başlatılamadı. Lütfen sayfayı yenileyin.');
    }
});

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
    // Ctrl+S or Cmd+S to save draft
    if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        document.getElementById('saveDraftBtn').click();
    }
});
