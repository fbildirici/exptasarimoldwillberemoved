/**
 * Login Page Script
 * Handles user authentication on the login page
 */

document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const togglePassword = document.getElementById('togglePassword');
    const errorMessage = document.getElementById('errorMessage');
    const errorText = document.getElementById('errorText');
    const loginBtn = document.getElementById('loginBtn');
    const rememberMe = document.getElementById('rememberMe');

    // Check if already logged in
    const existingUser = localStorage.getItem('ecaUser');
    if (existingUser) {
        const user = JSON.parse(existingUser);
        if (user.isAuthenticated) {
            window.location.href = 'index.html';
            return;
        }
    }

    // Load remembered username
    const rememberedUsername = localStorage.getItem('ecaRememberedUsername');
    if (rememberedUsername) {
        usernameInput.value = rememberedUsername;
        rememberMe.checked = true;
    }

    // Toggle password visibility
    togglePassword.addEventListener('click', () => {
        const type = passwordInput.type === 'password' ? 'text' : 'password';
        passwordInput.type = type;

        const eyeIcon = togglePassword.querySelector('.eye-icon');
        const eyeOffIcon = togglePassword.querySelector('.eye-off-icon');

        if (type === 'text') {
            eyeIcon.style.display = 'none';
            eyeOffIcon.style.display = 'block';
        } else {
            eyeIcon.style.display = 'block';
            eyeOffIcon.style.display = 'none';
        }
    });

    // Valid users
    const validUsers = {
        'admin': {
            password: 'admin123',
            role: 'admin',
            name: 'Administrator',
            permissions: ['read', 'write', 'delete', 'admin']
        },
        'user': {
            password: 'user123',
            role: 'user',
            name: 'Standard User',
            permissions: ['read', 'write']
        }
    };

    // Handle form submission
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const username = usernameInput.value.trim().toLowerCase();
        const password = passwordInput.value;

        // Hide previous error
        errorMessage.style.display = 'none';

        // Show loading state
        loginBtn.disabled = true;
        loginBtn.querySelector('.btn-text').style.display = 'none';
        loginBtn.querySelector('.btn-loading').style.display = 'flex';

        // Simulate network delay for better UX
        await new Promise(resolve => setTimeout(resolve, 300));

        // Validate credentials
        const user = validUsers[username];

        if (user && user.password === password) {
            // Remember username if checked
            if (rememberMe.checked) {
                localStorage.setItem('ecaRememberedUsername', username);
            } else {
                localStorage.removeItem('ecaRememberedUsername');
            }

            // Create user session
            const userSession = {
                username: username,
                name: user.name,
                role: user.role,
                permissions: user.permissions,
                initials: getInitials(user.name),
                isAuthenticated: true,
                loginTime: new Date().toISOString()
            };

            localStorage.setItem('ecaUser', JSON.stringify(userSession));

            // Redirect to home page immediately
            window.location.href = 'index.html';
        } else {
            // Show error
            errorText.textContent = 'Kullanıcı adı veya şifre hatalı';
            errorMessage.style.display = 'flex';

            // Reset button
            loginBtn.disabled = false;
            loginBtn.querySelector('.btn-text').style.display = 'block';
            loginBtn.querySelector('.btn-loading').style.display = 'none';

            // Shake animation
            passwordInput.value = '';
            passwordInput.focus();
        }
    });

    // Get initials from name
    function getInitials(name) {
        const words = name.trim().split(' ');
        if (words.length >= 2) {
            return (words[0][0] + words[words.length - 1][0]).toUpperCase();
        }
        return name.substring(0, 2).toUpperCase();
    }

    // Enter key handler
    usernameInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            passwordInput.focus();
        }
    });

    // Clear error on input
    [usernameInput, passwordInput].forEach(input => {
        input.addEventListener('input', () => {
            errorMessage.style.display = 'none';
        });
    });
});
