/**
 * Auto-Save Functionality
 * Automatic form state persistence
 */

class AutoSave {
    constructor(storageKey, saveCallback, interval = 30000) {
        this.storageKey = storageKey;
        this.saveCallback = saveCallback;
        this.interval = interval;
        this.timerId = null;
        this.lastSaveTime = null;
    }

    // Start auto-save
    start() {
        if (this.timerId) {
            this.stop();
        }

        this.timerId = setInterval(() => {
            this.save();
        }, this.interval);

        console.log(`Auto-save started (every ${this.interval / 1000}s)`);
    }

    // Stop auto-save
    stop() {
        if (this.timerId) {
            clearInterval(this.timerId);
            this.timerId = null;
            console.log('Auto-save stopped');
        }
    }

    // Save now
    save() {
        if (this.saveCallback) {
            const result = this.saveCallback();
            if (result) {
                this.lastSaveTime = new Date();
                this.showSaveIndicator();
                return true;
            }
        }
        return false;
    }

    // Show save indicator
    showSaveIndicator() {
        const indicator = document.getElementById('autosaveIndicator');
        if (indicator) {
            indicator.classList.add('show');
            setTimeout(() => {
                indicator.classList.remove('show');
            }, 2000);
        }
    }

    // Get last save time
    getLastSaveTime() {
        return this.lastSaveTime;
    }

    // Get time since last save
    getTimeSinceLastSave() {
        if (!this.lastSaveTime) return null;
        return Date.now() - this.lastSaveTime.getTime();
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { AutoSave };
}
