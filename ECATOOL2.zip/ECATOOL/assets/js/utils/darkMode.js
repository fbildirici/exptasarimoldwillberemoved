/**
 * Dark Mode Toggle
 * Persistent dark mode with smooth transitions
 */

class DarkModeManager {
    constructor() {
        this.darkModeKey = 'ecaDarkMode';
        this.init();
    }

    init() {
        // Load saved preference
        const savedMode = localStorage.getItem(this.darkModeKey);
        if (savedMode === 'dark') {
            this.enableDarkMode(false);
        } else if (savedMode === 'light') {
            this.disableDarkMode(false);
        } else {
            // Check system preference
            if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
                this.enableDarkMode(false);
            }
        }

        // Attach toggle button
        const toggleBtn = document.getElementById('darkModeToggle');
        if (toggleBtn) {
            toggleBtn.addEventListener('click', () => this.toggle());
        }

        // Listen for system preference changes
        if (window.matchMedia) {
            window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => {
                if (!localStorage.getItem(this.darkModeKey)) {
                    if (e.matches) {
                        this.enableDarkMode();
                    } else {
                        this.disableDarkMode();
                    }
                }
            });
        }
    }

    toggle() {
        if (document.body.classList.contains('dark-mode')) {
            this.disableDarkMode();
        } else {
            this.enableDarkMode();
        }
    }

    enableDarkMode(animate = true) {
        if (animate) {
            document.body.style.transition = 'background-color 0.3s ease, color 0.3s ease';
        }
        document.body.classList.add('dark-mode');
        localStorage.setItem(this.darkModeKey, 'dark');

        if (animate) {
            setTimeout(() => {
                document.body.style.transition = '';
            }, 300);
        }
    }

    disableDarkMode(animate = true) {
        if (animate) {
            document.body.style.transition = 'background-color 0.3s ease, color 0.3s ease';
        }
        document.body.classList.remove('dark-mode');
        localStorage.setItem(this.darkModeKey, 'light');

        if (animate) {
            setTimeout(() => {
                document.body.style.transition = '';
            }, 300);
        }
    }

    isDarkMode() {
        return document.body.classList.contains('dark-mode');
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    window.darkModeManager = new DarkModeManager();
});
