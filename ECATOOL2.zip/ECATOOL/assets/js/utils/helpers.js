/**
 * Utility Helper Functions
 * XSS protection, date formatting, and common utilities
 */

// XSS Protection
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

function sanitizeInput(input) {
    if (typeof input !== 'string') return input;
    return escapeHtml(input.trim());
}

// Date Formatting
function formatDate(dateString) {
    const date = new Date(dateString);
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return date.toLocaleDateString('tr-TR', options);
}

function formatDateTime(dateString) {
    const date = new Date(dateString);
    const dateOptions = { year: 'numeric', month: 'short', day: 'numeric' };
    const timeOptions = { hour: '2-digit', minute: '2-digit' };
    return date.toLocaleDateString('tr-TR', dateOptions) + ' ' + date.toLocaleTimeString('tr-TR', timeOptions);
}

function getRelativeTime(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Az önce';
    if (diffMins < 60) return `${diffMins} dakika önce`;
    if (diffHours < 24) return `${diffHours} saat önce`;
    if (diffDays < 7) return `${diffDays} gün önce`;
    return formatDate(dateString);
}

// Local Storage Helpers
function getFromStorage(key, defaultValue = null) {
    try {
        const item = localStorage.getItem(key);
        return item ? JSON.parse(item) : defaultValue;
    } catch (error) {
        console.error('Error reading from localStorage:', error);
        return defaultValue;
    }
}

function saveToStorage(key, value) {
    try {
        localStorage.setItem(key, JSON.stringify(value));
        return true;
    } catch (error) {
        console.error('Error writing to localStorage:', error);
        return false;
    }
}

function removeFromStorage(key) {
    try {
        localStorage.removeItem(key);
        return true;
    } catch (error) {
        console.error('Error removing from localStorage:', error);
        return false;
    }
}

// CSV Export/Import
function exportToCsv(data, filename = 'export.csv') {
    if (!data || data.length === 0) {
        showToast('warning', 'Uyarı', 'Dışa aktarılacak veri bulunamadı');
        return;
    }

    const headers = Object.keys(data[0]);
    const csvContent = [
        headers.join(','),
        ...data.map(row =>
            headers.map(header => {
                const value = row[header] || '';
                // Escape quotes and wrap in quotes if contains comma
                const escaped = String(value).replace(/"/g, '""');
                return escaped.includes(',') ? `"${escaped}"` : escaped;
            }).join(',')
        )
    ].join('\n');

    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);

    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    showToast('success', 'Başarılı', 'CSV dosyası indirildi');
}

function parseCsv(csvText) {
    const lines = csvText.split('\n').filter(line => line.trim());
    if (lines.length === 0) return [];

    const headers = lines[0].split(',').map(h => h.trim());
    const data = [];

    for (let i = 1; i < lines.length; i++) {
        const values = lines[i].split(',').map(v => v.trim().replace(/^"|"$/g, ''));
        const row = {};
        headers.forEach((header, index) => {
            row[header] = values[index] || '';
        });
        data.push(row);
    }

    return data;
}

// Debounce Function
function debounce(func, wait = 300) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Generate Unique ID
function generateId(prefix = 'id') {
    return `${prefix}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

// Copy to Clipboard
function copyToClipboard(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text)
            .then(() => {
                showToast('success', 'Kopyalandı', 'Panoya kopyalandı');
            })
            .catch(err => {
                console.error('Failed to copy:', err);
                fallbackCopyToClipboard(text);
            });
    } else {
        fallbackCopyToClipboard(text);
    }
}

function fallbackCopyToClipboard(text) {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();

    try {
        document.execCommand('copy');
        showToast('success', 'Kopyalandı', 'Panoya kopyalandı');
    } catch (err) {
        showToast('error', 'Hata', 'Kopyalama başarısız oldu');
    }

    document.body.removeChild(textArea);
}

// Query String Helpers
function getUrlParam(param) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(param);
}

function setUrlParam(param, value) {
    const url = new URL(window.location.href);
    url.searchParams.set(param, value);
    window.history.pushState({}, '', url);
}

// Email Template Generator
function generateEmailHtml(assessment) {
    const trackColors = {
        simple: '#2ecc40',
        complex: '#ff9800',
        full: '#e53935'
    };

    const trackLabels = {
        simple: 'Fast-Track Simple',
        complex: 'Fast-Track Complex',
        full: 'Full-Track'
    };

    const trackIcons = {
        simple: '⚡',
        complex: '🔍',
        full: '⚠️'
    };

    return `
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: linear-gradient(135deg, #003080, #002060); padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
                .header h1 { color: #fff !important; font-size: 2rem; font-weight: bold; margin: 0; }
                .content { background: #f8f9fa; padding: 30px; }
                .badge { display: inline-block; padding: 8px 16px; border-radius: 20px; font-weight: bold; color: white; }
                .score { font-size: 48px; font-weight: bold; color: #003080; text-align: center; margin: 20px 0; }
                .detail { margin: 10px 0; padding: 10px; background: white; border-radius: 4px; }
                .label { font-weight: bold; color: #666; }
                .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>ECA Tool - Değerlendirme Sonucu</h1>
                </div>
                <div class="content">
                    <div class="score">${assessment.score} Puan</div>
                    <div style="text-align: center; margin: 20px 0;">
                        <span class="badge" style="background-color: ${trackColors[assessment.track]}">
                            ${trackIcons[assessment.track]} ${trackLabels[assessment.track]}
                        </span>
                    </div>
                    <div class="detail">
                        <span class="label">Değişiklik ID:</span> ${escapeHtml(assessment.data.changeId || '-')}
                    </div>
                    <div class="detail">
                        <span class="label">Açıklama:</span> ${escapeHtml(assessment.data.changeDescription || '-')}
                    </div>
                    <div class="detail">
                        <span class="label">Tarih:</span> ${formatDate(assessment.timestamp)}
                    </div>
                    ${assessment.autoFullTrack ? `
                    <div class="detail" style="background: #fff3cd; border-left: 4px solid #ff9800;">
                        <span class="label">Otomatik Full-Track Nedeni:</span> ${escapeHtml(assessment.autoFullTrackReason)}
                    </div>
                    ` : ''}
                </div>
                <div class="footer">
                    <p>Bu e-posta ECA Tool tarafından otomatik olarak oluşturulmuştur.</p>
                    <p>&copy; 2026 ECA Tool. Tüm hakları saklıdır.</p>
                </div>
            </div>
        </body>
        </html>
    `;
}

// Export functions
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        escapeHtml,
        sanitizeInput,
        formatDate,
        formatDateTime,
        getRelativeTime,
        getFromStorage,
        saveToStorage,
        removeFromStorage,
        exportToCsv,
        parseCsv,
        debounce,
        generateId,
        copyToClipboard,
        getUrlParam,
        setUrlParam,
        generateEmailHtml
    };
}
