/**
 * IndexedDB Database Manager
 * Manages assessments and drafts in IndexedDB
 */

class DatabaseManager {
    constructor() {
        this.dbName = 'ECA_Tool_DB';
        this.version = 1;
        this.db = null;
    }

    /**
     * Initialize and open database
     */
    async init() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.dbName, this.version);

            request.onerror = () => {
                console.error('Database failed to open');
                reject(request.error);
            };

            request.onsuccess = () => {
                this.db = request.result;
                console.log('Database opened successfully');
                resolve(this.db);
            };

            request.onupgradeneeded = (e) => {
                const db = e.target.result;

                // Create assessments object store
                if (!db.objectStoreNames.contains('assessments')) {
                    const assessmentStore = db.createObjectStore('assessments', { keyPath: 'id' });
                    assessmentStore.createIndex('timestamp', 'timestamp', { unique: false });
                    assessmentStore.createIndex('changeId', 'data.changeId', { unique: false });
                }

                // Create drafts object store
                if (!db.objectStoreNames.contains('drafts')) {
                    const draftStore = db.createObjectStore('drafts', { keyPath: 'id' });
                    draftStore.createIndex('timestamp', 'timestamp', { unique: false });
                }

                console.log('Database setup complete');
            };
        });
    }

    /**
     * Add or update an assessment
     */
    async saveAssessment(assessment) {
        if (!this.db) await this.init();

        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['assessments'], 'readwrite');
            const store = transaction.objectStore('assessments');
            const request = store.put(assessment);

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    /**
     * Get all assessments
     */
    async getAllAssessments() {
        if (!this.db) await this.init();

        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['assessments'], 'readonly');
            const store = transaction.objectStore('assessments');
            const request = store.getAll();

            request.onsuccess = () => resolve(request.result || []);
            request.onerror = () => reject(request.error);
        });
    }

    /**
     * Get assessment by ID
     */
    async getAssessment(id) {
        if (!this.db) await this.init();

        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['assessments'], 'readonly');
            const store = transaction.objectStore('assessments');
            const request = store.get(id);

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    /**
     * Delete assessment by ID
     */
    async deleteAssessment(id) {
        if (!this.db) await this.init();

        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['assessments'], 'readwrite');
            const store = transaction.objectStore('assessments');
            const request = store.delete(id);

            request.onsuccess = () => resolve();
            request.onerror = () => reject(request.error);
        });
    }

    /**
     * Delete multiple assessments
     */
    async deleteAssessments(ids) {
        if (!this.db) await this.init();

        const transaction = this.db.transaction(['assessments'], 'readwrite');
        const store = transaction.objectStore('assessments');

        const promises = ids.map(id => {
            return new Promise((resolve, reject) => {
                const request = store.delete(id);
                request.onsuccess = () => resolve();
                request.onerror = () => reject(request.error);
            });
        });

        return Promise.all(promises);
    }

    /**
     * Save or update a draft
     */
    async saveDraft(draft) {
        if (!this.db) await this.init();

        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['drafts'], 'readwrite');
            const store = transaction.objectStore('drafts');
            const request = store.put(draft);

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    /**
     * Get all drafts
     */
    async getAllDrafts() {
        if (!this.db) await this.init();

        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['drafts'], 'readonly');
            const store = transaction.objectStore('drafts');
            const request = store.getAll();

            request.onsuccess = () => resolve(request.result || []);
            request.onerror = () => reject(request.error);
        });
    }

    /**
     * Get draft by ID
     */
    async getDraft(id) {
        if (!this.db) await this.init();

        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['drafts'], 'readonly');
            const store = transaction.objectStore('drafts');
            const request = store.get(id);

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    /**
     * Delete draft by ID
     */
    async deleteDraft(id) {
        if (!this.db) await this.init();

        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['drafts'], 'readwrite');
            const store = transaction.objectStore('drafts');
            const request = store.delete(id);

            request.onsuccess = () => resolve();
            request.onerror = () => reject(request.error);
        });
    }

    /**
     * Clear all data (for testing/reset)
     */
    async clearAll() {
        if (!this.db) await this.init();

        const transaction = this.db.transaction(['assessments', 'drafts'], 'readwrite');

        return Promise.all([
            new Promise((resolve, reject) => {
                const request = transaction.objectStore('assessments').clear();
                request.onsuccess = () => resolve();
                request.onerror = () => reject(request.error);
            }),
            new Promise((resolve, reject) => {
                const request = transaction.objectStore('drafts').clear();
                request.onsuccess = () => resolve();
                request.onerror = () => reject(request.error);
            })
        ]);
    }

    /**
     * Migrate data from localStorage to IndexedDB
     */
    async migrateFromLocalStorage() {
        try {
            // Migrate assessments
            const assessments = JSON.parse(localStorage.getItem('ecaAssessments') || '[]');
            if (assessments.length > 0) {
                for (const assessment of assessments) {
                    await this.saveAssessment(assessment);
                }
                console.log(`Migrated ${assessments.length} assessments from localStorage`);
            }

            // Migrate drafts
            const drafts = JSON.parse(localStorage.getItem('ecaDrafts') || '[]');
            if (drafts.length > 0) {
                for (const draft of drafts) {
                    await this.saveDraft(draft);
                }
                console.log(`Migrated ${drafts.length} drafts from localStorage`);
            }

            // Clear localStorage after migration
            localStorage.removeItem('ecaAssessments');
            localStorage.removeItem('ecaDrafts');

            return { assessments: assessments.length, drafts: drafts.length };
        } catch (error) {
            console.error('Migration error:', error);
            throw error;
        }
    }
}

// Create global instance
window.dbManager = new DatabaseManager();

// Create a promise that resolves when DB is ready
window.dbReady = (async () => {
    try {
        await window.dbManager.init();
        console.log('Database initialized successfully');

        // Check if migration is needed
        const hasOldData = localStorage.getItem('ecaAssessments') || localStorage.getItem('ecaDrafts');
        if (hasOldData) {
            const migrationResult = await window.dbManager.migrateFromLocalStorage();
            if (migrationResult.assessments > 0 || migrationResult.drafts > 0) {
                console.log('Migration completed:', migrationResult);
                if (typeof showToast === 'function') {
                    showToast('success', 'Veri Taşındı',
                        `${migrationResult.assessments} değerlendirme ve ${migrationResult.drafts} taslak yeni veritabanına taşındı`);
                }
            }
        }
        return window.dbManager;
    } catch (error) {
        console.error('Database initialization error:', error);
        throw error;
    }
})();
