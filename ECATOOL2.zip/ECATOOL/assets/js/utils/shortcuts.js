/**
 * Keyboard Shortcuts
 * Global keyboard shortcuts for accessibility
 */

class KeyboardShortcuts {
    constructor() {
        this.shortcuts = {
            // Global shortcuts
            'ctrl+k': () => this.focusSearch(),
            'ctrl+/': () => this.showHelp(),
            'esc': () => this.closeModals(),

            // Navigation
            'ctrl+h': () => window.location.href = 'index.html',
            'ctrl+n': () => window.location.href = 'assessment.html',
            'ctrl+l': () => window.location.href = 'history.html',

            // Assessment page
            'ctrl+s': (e) => this.saveDraft(e),
            'ctrl+enter': () => this.submitForm(),
        };

        this.init();
    }

    init() {
        document.addEventListener('keydown', (e) => {
            const key = this.getKeyCombo(e);

            if (this.shortcuts[key]) {
                const shouldPrevent = this.shortcuts[key](e);
                if (shouldPrevent !== false) {
                    e.preventDefault();
                }
            }
        });

        // Show shortcuts hint on first visit
        this.showShortcutsHint();
    }

    getKeyCombo(e) {
        const keys = [];

        if (e.ctrlKey || e.metaKey) keys.push('ctrl');
        if (e.shiftKey) keys.push('shift');
        if (e.altKey) keys.push('alt');

        const key = e.key.toLowerCase();
        if (!['control', 'shift', 'alt', 'meta'].includes(key)) {
            keys.push(key === 'escape' ? 'esc' : key);
        }

        return keys.join('+');
    }

    focusSearch() {
        const searchInput = document.querySelector('input[type="search"], input[placeholder*="ara"]');
        if (searchInput) {
            searchInput.focus();
            searchInput.select();
        }
    }

    showHelp() {
        const helpText = `
Klavye Kısayolları:
-------------------
Ctrl + K: Aramaya odaklan
Ctrl + H: Ana sayfaya git
Ctrl + N: Yeni değerlendirme
Ctrl + L: Geçmiş sayfası
Ctrl + S: Taslak kaydet
Ctrl + Enter: Formu gönder
Esc: Modalları kapat
        `.trim();

        showToast('info', 'Klavye Kısayolları', helpText, 8000);
    }

    closeModals() {
        document.querySelectorAll('.modal.show').forEach(modal => {
            modal.classList.remove('show');
        });
    }

    saveDraft(e) {
        const saveBtn = document.getElementById('saveDraftBtn');
        if (saveBtn && !saveBtn.disabled) {
            e.preventDefault();
            saveBtn.click();
            return true;
        }
        return false;
    }

    submitForm() {
        const submitBtn = document.getElementById('submitBtn');
        if (submitBtn && submitBtn.style.display !== 'none' && !submitBtn.disabled) {
            submitBtn.click();
        }
    }

    showShortcutsHint() {
        const hintShown = localStorage.getItem('shortcutsHintShown');
        if (!hintShown) {
            setTimeout(() => {
                showToast('info', 'İpucu', 'Ctrl + / tuşlarına basarak klavye kısayollarını görebilirsiniz', 6000);
                localStorage.setItem('shortcutsHintShown', 'true');
            }, 3000);
        }
    }
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    new KeyboardShortcuts();
});
