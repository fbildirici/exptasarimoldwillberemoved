/**
 * ECA Tool - Main Application
 * Core application logic and initialization
 */

// App Configuration
const APP_CONFIG = {
    name: 'ECA Tool',
    version: '2.0.0',
    autoSaveInterval: 30000, // 30 seconds
    toastDuration: 4000
};

// Initialize app on DOM ready
document.addEventListener('DOMContentLoaded', () => {
    initializeApp();
});

function initializeApp() {
    // Check browser compatibility
    checkBrowserCompatibility();

    // Initialize data structure
    initializeDataStructure();

    // Setup global error handler
    setupErrorHandler();

    // Add smooth scroll
    setupSmoothScroll();

    console.log(`${APP_CONFIG.name} v${APP_CONFIG.version} initialized`);
}

function checkBrowserCompatibility() {
    const features = {
        localStorage: typeof Storage !== 'undefined',
        flexbox: CSS.supports('display', 'flex'),
        grid: CSS.supports('display', 'grid')
    };

    const unsupported = Object.keys(features).filter(key => !features[key]);

    if (unsupported.length > 0) {
        console.warn('Unsupported features:', unsupported);
        showToast('warning', 'Uyarı', 'Tarayıcınız bazı özellikleri desteklemiyor olabilir');
    }
}

function initializeDataStructure() {
    // Initialize localStorage structure if not exists
    if (!localStorage.getItem('ecaAssessments')) {
        localStorage.setItem('ecaAssessments', JSON.stringify([]));
    }

    if (!localStorage.getItem('ecaDrafts')) {
        localStorage.setItem('ecaDrafts', JSON.stringify([]));
    }
}

function setupErrorHandler() {
    window.addEventListener('error', (event) => {
        console.error('Global error:', event.error);
        showToast('error', 'Bir Hata Oluştu', 'Lütfen sayfayı yenileyin');
    });

    window.addEventListener('unhandledrejection', (event) => {
        console.error('Unhandled promise rejection:', event.reason);
    });
}

function setupSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const href = this.getAttribute('href');
            if (href === '#') return;

            e.preventDefault();
            const target = document.querySelector(href);

            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// Export for global use
window.APP_CONFIG = APP_CONFIG;
