/**
 * Profile Page Script
 * Handles user profile management
 */

class ProfileManager {
    constructor() {
        this.currentUser = null;
        this.profileData = null;
        this.init();
    }

    async init() {
        // Check authentication
        const savedUser = localStorage.getItem('ecaUser');
        if (!savedUser) {
            window.location.href = 'login.html';
            return;
        }

        this.currentUser = JSON.parse(savedUser);

        if (!this.currentUser.isAuthenticated) {
            window.location.href = 'login.html';
            return;
        }

        // Load profile data
        this.loadProfileData();

        // Setup UI
        this.updateHeaderInfo();
        this.populateForm();
        this.setupEventListeners();
        await this.loadStatistics();
    }

    loadProfileData() {
        // Load saved profile data from localStorage
        const savedProfile = localStorage.getItem('ecaProfile_' + this.currentUser.username);
        if (savedProfile) {
            this.profileData = JSON.parse(savedProfile);
        } else {
            // Default profile data
            this.profileData = {
                displayName: this.currentUser.name,
                email: '',
                department: '',
                phone: '',
                bio: ''
            };
        }
    }

    updateHeaderInfo() {
        // Update profile header
        const profileAvatar = document.getElementById('profileAvatar');
        const profileInitials = document.getElementById('profileInitials');
        const profileName = document.getElementById('profileName');
        const roleBadge = document.getElementById('roleBadge');
        const roleText = document.getElementById('roleText');
        const lastLoginTime = document.getElementById('lastLoginTime');

        // Set initials
        profileInitials.textContent = this.currentUser.initials || 'U';

        // Set name
        profileName.textContent = this.profileData.displayName || this.currentUser.name;

        // Set role styling
        if (this.currentUser.role === 'admin') {
            profileAvatar.classList.add('admin');
            roleText.textContent = 'Yönetici';
            roleBadge.innerHTML = `
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                </svg>
                <span>Yönetici</span>
            `;
        } else {
            profileAvatar.classList.add('user');
            roleText.textContent = 'Kullanıcı';
            roleBadge.innerHTML = `
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                    <circle cx="12" cy="7" r="4"/>
                </svg>
                <span>Kullanıcı</span>
            `;
        }

        // Set last login time
        if (this.currentUser.loginTime) {
            const loginDate = new Date(this.currentUser.loginTime);
            lastLoginTime.textContent = loginDate.toLocaleString('tr-TR', {
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
        }
    }

    populateForm() {
        // Personal information
        document.getElementById('displayName').value = this.profileData.displayName || '';
        document.getElementById('email').value = this.profileData.email || '';
        document.getElementById('department').value = this.profileData.department || '';
        document.getElementById('phone').value = this.profileData.phone || '';
        document.getElementById('bio').value = this.profileData.bio || '';

        // Account settings (read-only)
        document.getElementById('username').value = this.currentUser.username;
        document.getElementById('role').value = this.currentUser.role === 'admin' ? 'Yönetici' : 'Kullanıcı';
    }

    setupEventListeners() {
        // Save profile button
        document.getElementById('saveProfileBtn').addEventListener('click', () => {
            this.saveProfile();
        });

        // Cancel button
        document.getElementById('cancelProfileBtn').addEventListener('click', () => {
            this.populateForm(); // Reset to saved values
            showToast('info', 'İptal Edildi', 'Değişiklikler geri alındı');
        });

        // Change password button
        document.getElementById('changePasswordBtn').addEventListener('click', () => {
            this.changePassword();
        });

        // Form enter key handling
        document.getElementById('profileForm').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                this.saveProfile();
            }
        });

        document.getElementById('passwordForm').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                this.changePassword();
            }
        });
    }

    saveProfile() {
        // Get form values
        const displayName = document.getElementById('displayName').value.trim();
        const email = document.getElementById('email').value.trim();
        const department = document.getElementById('department').value;
        const phone = document.getElementById('phone').value.trim();
        const bio = document.getElementById('bio').value.trim();

        // Validate
        if (!displayName) {
            showToast('error', 'Hata', 'Ad Soyad alanı zorunludur');
            document.getElementById('displayName').focus();
            return;
        }

        if (email && !this.isValidEmail(email)) {
            showToast('error', 'Hata', 'Geçerli bir e-posta adresi girin');
            document.getElementById('email').focus();
            return;
        }

        // Save profile data
        this.profileData = {
            displayName,
            email,
            department,
            phone,
            bio,
            updatedAt: new Date().toISOString()
        };

        localStorage.setItem('ecaProfile_' + this.currentUser.username, JSON.stringify(this.profileData));

        // Update current user name if changed
        if (displayName !== this.currentUser.name) {
            this.currentUser.name = displayName;
            this.currentUser.initials = this.getInitials(displayName);
            localStorage.setItem('ecaUser', JSON.stringify(this.currentUser));
        }

        // Update header
        this.updateHeaderInfo();

        showToast('success', 'Kaydedildi', 'Profil bilgileriniz güncellendi');
    }

    changePassword() {
        const currentPassword = document.getElementById('currentPassword').value;
        const newPassword = document.getElementById('newPassword').value;
        const confirmPassword = document.getElementById('confirmPassword').value;

        // Validate current password
        if (!currentPassword) {
            showToast('error', 'Hata', 'Mevcut şifrenizi girin');
            document.getElementById('currentPassword').focus();
            return;
        }

        // Check current password (demo purposes - in real app this would be server-side)
        const validPasswords = {
            'admin': 'admin123',
            'user': 'user123'
        };

        if (validPasswords[this.currentUser.username] !== currentPassword) {
            showToast('error', 'Hata', 'Mevcut şifre yanlış');
            document.getElementById('currentPassword').focus();
            return;
        }

        // Validate new password
        if (!newPassword) {
            showToast('error', 'Hata', 'Yeni şifre girin');
            document.getElementById('newPassword').focus();
            return;
        }

        if (newPassword.length < 6) {
            showToast('error', 'Hata', 'Şifre en az 6 karakter olmalıdır');
            document.getElementById('newPassword').focus();
            return;
        }

        if (!/[A-Z]/.test(newPassword)) {
            showToast('error', 'Hata', 'Şifre en az bir büyük harf içermelidir');
            document.getElementById('newPassword').focus();
            return;
        }

        if (!/[0-9]/.test(newPassword)) {
            showToast('error', 'Hata', 'Şifre en az bir rakam içermelidir');
            document.getElementById('newPassword').focus();
            return;
        }

        // Validate confirm password
        if (newPassword !== confirmPassword) {
            showToast('error', 'Hata', 'Şifreler eşleşmiyor');
            document.getElementById('confirmPassword').focus();
            return;
        }

        // In a real application, this would be sent to the server
        // For demo purposes, we'll just show a success message
        showToast('success', 'Başarılı', 'Şifreniz güncellendi (Demo: Gerçek şifre değiştirilmedi)');

        // Clear password fields
        document.getElementById('currentPassword').value = '';
        document.getElementById('newPassword').value = '';
        document.getElementById('confirmPassword').value = '';
    }

    async loadStatistics() {
        try {
            // Wait for database to be ready
            if (window.dbReady) {
                await window.dbReady;
            }

            // Get assessment count
            if (window.dbManager) {
                const assessments = await window.dbManager.getAllAssessments();
                document.getElementById('totalAssessments').textContent = assessments.length;

                const drafts = await window.dbManager.getAllDrafts();
                document.getElementById('totalDrafts').textContent = drafts.length;
            }

            // Calculate account age
            if (this.currentUser.loginTime) {
                const loginDate = new Date(this.currentUser.loginTime);
                const now = new Date();
                const diffTime = Math.abs(now - loginDate);
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                document.getElementById('accountAge').textContent = diffDays;
            }
        } catch (error) {
            console.error('Error loading statistics:', error);
        }
    }

    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    getInitials(name) {
        const words = name.trim().split(' ');
        if (words.length >= 2) {
            return (words[0][0] + words[words.length - 1][0]).toUpperCase();
        }
        return name.substring(0, 2).toUpperCase();
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    window.profileManager = new ProfileManager();
});
