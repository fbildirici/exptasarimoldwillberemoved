/**
 * Authentication System
 * Complete authentication with role-based access control
 */

class AuthManager {
    constructor() {
        this.currentUser = null;
        this.init();
    }

    init() {
        // Load saved user
        const savedUser = localStorage.getItem('ecaUser');
        if (savedUser) {
            this.currentUser = JSON.parse(savedUser);
        }

        // Update UI
        this.updateUI();

        // Apply read-only mode if guest
        this.applyAccessControl();

        // Listen for storage changes (for multi-tab sync)
        window.addEventListener('storage', (e) => {
            if (e.key === 'ecaUser') {
                this.currentUser = e.newValue ? JSON.parse(e.newValue) : null;
                this.updateUI();
                this.applyAccessControl();
            }
        });
    }

    /**
     * Check if user is authenticated
     */
    isAuthenticated() {
        return this.currentUser !== null && this.currentUser.isAuthenticated === true;
    }

    /**
     * Check if user is admin
     */
    isAdmin() {
        return this.isAuthenticated() && this.currentUser.role === 'admin';
    }

    /**
     * Check if user has specific permission
     */
    hasPermission(permission) {
        if (!this.isAuthenticated()) return false;
        return this.currentUser.permissions && this.currentUser.permissions.includes(permission);
    }

    /**
     * Check if user can edit (write permission)
     */
    canEdit() {
        return this.hasPermission('write');
    }

    /**
     * Get current user
     */
    getCurrentUser() {
        return this.currentUser;
    }

    /**
     * Logout user
     */
    logout() {
        this.currentUser = null;
        localStorage.removeItem('ecaUser');
        this.updateUI();

        // Dispatch event
        window.dispatchEvent(new CustomEvent('authStateChanged', {
            detail: { isAuthenticated: false, user: null }
        }));

        // Show toast if available
        if (typeof showToast === 'function') {
            showToast('info', 'Çıkış Yapıldı', 'Başarıyla çıkış yaptınız');
        }

        // Redirect to login page
        setTimeout(() => {
            window.location.href = 'login.html';
        }, 500);
    }

    /**
     * Update UI based on auth state
     */
    updateUI() {
        const avatar = document.getElementById('userAvatar');
        const initialsElement = document.getElementById('userInitials');
        const navActions = document.querySelector('.nav-actions');

        if (!avatar || !initialsElement) return;

        // Remove existing user menu if any
        const existingMenu = document.querySelector('.user-menu-dropdown');
        if (existingMenu) {
            existingMenu.remove();
        }

        if (this.isAuthenticated()) {
            // Show avatar for authenticated users
            avatar.style.display = 'flex';
            initialsElement.textContent = this.currentUser.initials || 'U';
            avatar.title = `${this.currentUser.name} (${this.currentUser.role === 'admin' ? 'Yönetici' : 'Kullanıcı'})`;
            avatar.classList.add('authenticated');

            // Set avatar color based on role
            if (this.currentUser.role === 'admin') {
                avatar.style.background = 'linear-gradient(135deg, #2ecc40, #27ae60)';
            } else {
                avatar.style.background = 'linear-gradient(135deg, #003080, #001a4d)';
            }

            // Create user menu dropdown
            this.createUserMenu(avatar);
        } else {
            // Hide avatar for guests - login button is shown instead
            avatar.style.display = 'none';
        }

        // Update nav actions with login/logout button
        this.updateNavActions(navActions);
    }

    /**
     * Create user menu dropdown
     */
    createUserMenu(avatar) {
        const menuWrapper = document.createElement('div');
        menuWrapper.className = 'user-menu';

        // Move avatar into menu wrapper
        avatar.parentNode.insertBefore(menuWrapper, avatar);
        menuWrapper.appendChild(avatar);

        // Create dropdown
        const dropdown = document.createElement('div');
        dropdown.className = 'user-menu-dropdown';
        dropdown.innerHTML = `
            <div class="user-menu-header">
                <div class="user-name">${this.currentUser.name}</div>
                <div class="user-role">${this.currentUser.role === 'admin' ? 'Yönetici' : 'Kullanıcı'}</div>
            </div>
            <div class="user-menu-items">
                <button class="user-menu-item" id="menuProfile">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                        <circle cx="12" cy="7" r="4"/>
                    </svg>
                    Profil
                </button>
                <button class="user-menu-item danger" id="menuLogout">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
                        <polyline points="16 17 21 12 16 7"/>
                        <line x1="21" y1="12" x2="9" y2="12"/>
                    </svg>
                    Çıkış Yap
                </button>
            </div>
        `;
        menuWrapper.appendChild(dropdown);

        // Toggle menu on avatar click
        avatar.style.cursor = 'pointer';
        avatar.onclick = (e) => {
            e.stopPropagation();
            menuWrapper.classList.toggle('active');
        };

        // Close menu on outside click
        document.addEventListener('click', (e) => {
            if (!menuWrapper.contains(e.target)) {
                menuWrapper.classList.remove('active');
            }
        });

        // Logout button handler
        dropdown.querySelector('#menuLogout').addEventListener('click', () => {
            if (confirm('Çıkış yapmak istediğinizden emin misiniz?')) {
                this.logout();
            }
        });

        // Profile button handler (placeholder)
        dropdown.querySelector('#menuProfile').addEventListener('click', () => {
            if (typeof showToast === 'function') {
                showToast('info', 'Bilgi', `Kullanıcı: ${this.currentUser.name}\nRol: ${this.currentUser.role === 'admin' ? 'Yönetici' : 'Kullanıcı'}`);
            }
            menuWrapper.classList.remove('active');
        });
    }

    /**
     * Update navigation actions
     */
    updateNavActions(navActions) {
        if (!navActions) return;

        // Remove existing login button
        const existingLoginBtn = navActions.querySelector('.nav-login-btn');
        if (existingLoginBtn) {
            existingLoginBtn.remove();
        }

        if (!this.isAuthenticated()) {
            // Add login button for guests
            const loginBtn = document.createElement('a');
            loginBtn.href = 'login.html';
            loginBtn.className = 'btn-primary btn-sm nav-login-btn';
            loginBtn.innerHTML = `
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/>
                    <polyline points="10 17 15 12 10 7"/>
                    <line x1="15" y1="12" x2="3" y2="12"/>
                </svg>
                Giriş Yap
            `;
            navActions.insertBefore(loginBtn, navActions.firstChild);
        }
    }

    /**
     * Apply access control based on user permissions
     */
    applyAccessControl() {
        // Don't apply on login page
        if (window.location.pathname.includes('login.html')) return;

        if (!this.canEdit()) {
            // Show read-only banner
            this.showReadOnlyBanner();

            // Make forms read-only
            this.makeFormsReadOnly();
        } else {
            // Remove read-only restrictions
            this.removeReadOnlyBanner();
            this.enableForms();
        }
    }

    /**
     * Show read-only banner for guests
     */
    showReadOnlyBanner() {
        // Check if banner already exists
        if (document.querySelector('.readonly-banner')) return;

        const banner = document.createElement('div');
        banner.className = 'readonly-banner';
        banner.innerHTML = `
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                <circle cx="12" cy="12" r="3"/>
            </svg>
            <span>Sadece görüntüleme modu - Düzenleme için <a href="login.html">giriş yapın</a></span>
        `;

        // Insert after header
        const header = document.querySelector('.nav-header');
        if (header) {
            header.after(banner);
        } else {
            document.body.prepend(banner);
        }
    }

    /**
     * Remove read-only banner
     */
    removeReadOnlyBanner() {
        const banner = document.querySelector('.readonly-banner');
        if (banner) {
            banner.remove();
        }
    }

    /**
     * Make all forms read-only
     */
    makeFormsReadOnly() {
        // Add class to body for CSS targeting
        document.body.classList.add('guest-mode');

        // Disable all form inputs
        const forms = document.querySelectorAll('form');
        forms.forEach(form => {
            form.classList.add('form-readonly');

            // Disable all inputs
            form.querySelectorAll('input, textarea, select').forEach(input => {
                input.setAttribute('readonly', true);
                input.setAttribute('disabled', true);
            });

            // Disable radio buttons and checkboxes
            form.querySelectorAll('input[type="radio"], input[type="checkbox"]').forEach(input => {
                input.disabled = true;
            });

            // Hide submit buttons
            form.querySelectorAll('button[type="submit"], .btn-primary').forEach(btn => {
                if (!btn.classList.contains('btn-login') && !btn.classList.contains('nav-login-btn')) {
                    btn.style.display = 'none';
                }
            });
        });

        // Disable action buttons
        const actionBtns = document.querySelectorAll('#saveDraftBtn, #submitBtn, #nextBtn, #prevBtn, .card-action-btn.danger');
        actionBtns.forEach(btn => {
            if (btn.id !== 'nextBtn' && btn.id !== 'prevBtn') {
                btn.disabled = true;
                btn.title = 'Bu işlem için giriş yapmanız gerekiyor';
            }
        });

        // Show toast notification
        if (!sessionStorage.getItem('guestNotified')) {
            setTimeout(() => {
                if (typeof showToast === 'function') {
                    showToast('info', 'Misafir Modu', 'Düzenleme yapmak için giriş yapmanız gerekiyor');
                }
            }, 1000);
            sessionStorage.setItem('guestNotified', 'true');
        }
    }

    /**
     * Enable forms for authenticated users
     */
    enableForms() {
        document.body.classList.remove('guest-mode');

        const forms = document.querySelectorAll('form');
        forms.forEach(form => {
            form.classList.remove('form-readonly');

            form.querySelectorAll('input, textarea, select').forEach(input => {
                input.removeAttribute('readonly');
                input.removeAttribute('disabled');
            });

            form.querySelectorAll('input[type="radio"], input[type="checkbox"]').forEach(input => {
                input.disabled = false;
            });

            form.querySelectorAll('button[type="submit"], .btn-primary').forEach(btn => {
                btn.style.display = '';
            });
        });

        // Enable action buttons
        const actionBtns = document.querySelectorAll('#saveDraftBtn, #submitBtn, .card-action-btn');
        actionBtns.forEach(btn => {
            btn.disabled = false;
            btn.title = '';
        });
    }
}

// Helper functions for global access
function isAuthenticated() {
    return window.authManager && window.authManager.isAuthenticated();
}

function isAdmin() {
    return window.authManager && window.authManager.isAdmin();
}

function canEdit() {
    return window.authManager && window.authManager.canEdit();
}

function getCurrentUser() {
    const savedUser = localStorage.getItem('ecaUser');
    return savedUser ? JSON.parse(savedUser) : null;
}

function logout() {
    if (window.authManager) {
        window.authManager.logout();
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    window.authManager = new AuthManager();
});
