# ECA Tool - Kullanım Kılavuzu

## 🚀 Başlangıç

### Uygulamayı Açma
1. Tarayıcınızda `index.html` dosyasını açın
2. Veritabanı otomatik olarak başlatılır
3. Eski veriler varsa otomatik olarak yeni sisteme taşınır

### Test Etme
- `test-db.html` sayfasını açarak veritabanı fonksiyonlarını test edebilirsiniz
- Bu sayfa ile test verileri ekleyebilir ve veritabanı durumunu kontrol edebilirsiniz

## 📝 Değerlendirme Yapma

### Adım 1: Değerlendirme Formu
1. Ana sayfadan "Değerlendirmeye Başla" butonuna tıklayın
2. Veya doğrudan `assessment.html` sayfasını açın

### Adım 2: Form Doldurma

**Aşama 1 - Temel Bilgiler:**
- Değişiklik ID (zorunlu)
- Değişiklik Açıklaması
- Değişiklik Sınıfı (Sınıf 1 / Sınıf 2)
- Değişiklik Büyüklüğü (Major / Minor)
- Müşteri Talebi (Evet / Hayır)
- Teslimat Etkisi
- Test Altyapısı
- Üretim Altyapısı

**Aşama 2 - Detaylı Değerlendirme:**
- Gerekçe Matrisi
- Etkilenen Proje Sayısı
- Yan Sistem Etkisi
- Müşteri Dokümanı
- DK Teslimat
- Açık Sipariş
- Üretim/Satın Alma

### Adım 3: Kaydetme
- **Taslak Kaydet**: Formu yarım bırakıp daha sonra devam edebilirsiniz
- **Sonuçları Hesapla**: Değerlendirmeyi tamamlar ve sonuçları gösterir

### Otomatik Kaydetme
- Form her 30 saniyede bir otomatik olarak taslak olarak kaydedilir
- Taslaklar IndexedDB'de güvenle saklanır

## 📊 Sonuçları Görüntüleme

### Sonuç Sayfası
Değerlendirme tamamlandıktan sonra:
- Toplam puan gösterilir
- Önerilen track (Simple/Complex/Full) gösterilir
- Puan dağılımı detaylı şekilde listelenir
- Sonraki adımlar önerileri gösterilir

### İşlemler
- **CSV Export**: Sonuçları CSV dosyası olarak indir
- **Paylaş**: Link'i kopyala
- **Yeni Değerlendirme**: Yeni bir değerlendirme başlat
- **Geçmişe Dön**: Tüm değerlendirmeleri gör

## 📂 Geçmiş Sayfası

### Erişim
- Ana sayfadan "Geçmişi Görüntüle" butonuna tıklayın
- Veya menüden "Geçmiş" seçeneğini seçin

### Görünüm Seçenekleri

#### Kart Görünümü (Varsayılan)
- Değerlendirmeler kart şeklinde gösterilir
- Her kartta: ID, Açıklama, Puan, Track bilgileri
- Görsel olarak daha çekici

#### Liste Görünümü
- Değerlendirmeler tablo formatında gösterilir
- Daha kompakt görünüm
- Sütunlar: ID, Açıklama, Tarih, Puan, Track, İşlemler

**Görünüm Değiştirme:**
- "Kart/Liste" butonuna tıklayarak görünümler arasında geçiş yapın

### Filtreleme ve Arama

#### Sekmeler
- **Tamamlananlar**: Bitmiş değerlendirmeler
- **Taslaklar**: Yarım kalan değerlendirmeler

#### Arama
- Arama kutusuna değişiklik numarası veya açıklama yazın
- Sonuçlar anlık filtrelenir

### Kayıt İşlemleri

#### Tek Kayıt İşlemleri
Her kayıt kartında/satırında bulunan butonlar:
1. **Görüntüle**: Detaylı sonuçları görüntüle
2. **CSV**: Tek kaydı CSV olarak indir
3. **Mail**: E-posta önizlemesi oluştur
4. **Sil**: Kaydı sil (onay gerektirir)

#### Toplu İşlemler

**Kayıt Seçimi:**
1. Her kayıttaki checkbox'ı işaretleyin
2. Veya "Tümünü Seç" butonuna tıklayın

**Toplu Silme:**
1. Silinecek kayıtları seçin
2. "Seçilenleri Sil (X)" butonuna tıklayın
3. Onay dialogunda kabul edin
4. Seçili tüm kayıtlar silinir

**Toplu Export:**
- "Toplu CSV Export" butonuna tıklayın
- Tüm değerlendirmeler tek bir CSV dosyasında indirilir

### CSV İşlemleri

#### CSV Export
- **Format**: UTF-8 BOM destekli (Türkçe karakterler doğru görünür)
- **Sütunlar**:
  - Değişiklik ID
  - Açıklama
  - Tarih
  - Puan
  - Öneri (Track)
  - Sınıf
  - Büyüklük
  - Müşteri Talebi

#### CSV Import
1. "CSV Import" butonuna tıklayın
2. CSV dosyasını seçin
3. Veriler otomatik olarak içe aktarılır
4. Başarı mesajı gösterilir

**Not**: CSV formatı export ile uyumlu olmalıdır

### Taslak İşlemleri

Taslaklar sekmesinde:
- **Devam Et**: Taslağı yükleyip değerlendirmeyi tamamla
- **Sil**: Taslağı sil

## 💾 Veri Yönetimi

### Veritabanı Yapısı

Tüm veriler tarayıcıda IndexedDB'de saklanır:

**Assessments (Değerlendirmeler):**
- Tamamlanmış değerlendirmeler
- Puan, track, detaylar

**Drafts (Taslaklar):**
- Yarım kalan değerlendirmeler
- Form verileri
- Hangi aşamada kalındığı

### Veri Güvenliği

✅ **Avantajlar:**
- Sunucu gerektirmez
- Hızlı erişim
- Offline çalışabilir

⚠️ **Dikkat:**
- Veriler tarayıcı tarafında saklanır
- Tarayıcı cache temizlenirse veriler kaybolur
- Farklı tarayıcılarda veriler görünmez

### Yedekleme

**Önerilen Yöntem:**
1. Geçmiş sayfasını açın
2. "Toplu CSV Export" ile tüm verileri indirin
3. CSV dosyasını güvenli bir yerde saklayın
4. Gerektiğinde "CSV Import" ile geri yükleyin

## 🎨 Özelleştirme

### Dark Mode
- Sağ üst köşedeki ay/güneş ikonuna tıklayın
- Karanlık ve aydınlık tema arasında geçiş yapın
- Tercih tarayıcıda saklanır

### Kullanıcı Profili
- Sağ üst köşede kullanıcı avatarı
- İlk harfler gösterilir

## ⌨️ Klavye Kısayolları

### Değerlendirme Sayfasında
- **Ctrl/Cmd + S**: Taslak kaydet
- **Tab**: Sonraki alana geç
- **Enter**: Form gönder (son aşamada)

## 🔧 Sorun Giderme

### Veriler Görünmüyor
1. Tarayıcı konsolunu açın (F12)
2. Hata mesajlarını kontrol edin
3. `test-db.html` sayfasını açıp veritabanını test edin
4. Gerekirse sayfayı yenileyin (Ctrl+F5)

### Veritabanı Hatası
1. Tarayıcı ayarlarından IndexedDB'yi kontrol edin
2. Gizli mod kullanmıyorsanız emin olun
3. Tarayıcı güncellemelerini kontrol edin

### Kayıtlar Kayboldu
1. Tarayıcı cache'ini temizlediyseniz veriler kaybolmuştur
2. Yedek CSV dosyanız varsa import edin
3. Düzenli yedekleme alın

### Performans Sorunları
1. Çok fazla kayıt varsa eski kayıtları silin
2. Tarayıcı cache'ini temizleyin
3. Tarayıcıyı yeniden başlatın

## 📱 Mobil Kullanım

- Responsive tasarım sayesinde mobil cihazlarda da kullanılabilir
- Dokunmatik ekran desteği
- Menü otomatik hamburger menüye dönüşür

## 🔄 Güncelleme Notları

### Versiyon 2.0
- IndexedDB desteği
- Toplu silme özelliği
- Kart/Liste görünümü
- Geliştirilmiş CSV işlemleri
- Otomatik veri taşıma

## 💡 İpuçları

1. **Düzenli Yedekleme**: Haftada bir CSV export alın
2. **Taslak Kullanımı**: Uzun değerlendirmeler için taslak kaydedin
3. **Toplu İşlemler**: Eski kayıtları toplu olarak silin
4. **Arama Kullanın**: ID veya açıklama ile hızlıca bulun
5. **Dark Mode**: Göz yorulması için karanlık temayı kullanın

## 🆘 Destek

Sorun yaşarsanız:
1. `test-db.html` ile veritabanını test edin
2. Tarayıcı konsolundaki hata mesajlarını kontrol edin
3. Gerekirse veritabanını temizleyip yeniden başlayın

## 📞 İletişim

Geri bildirim ve önerileriniz için:
- GitHub Issues
- E-posta
- İletişim formu

---

**Son Güncelleme**: 2026-01-20
**Versiyon**: 2.0
