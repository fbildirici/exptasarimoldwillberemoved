# ECA Tool - Quick Start Guide

Get up and running with ECA Tool in under 2 minutes!

## ⚡ Fast Setup

### Step 1: Open the Project Folder
```bash
cd ECATOOL
```

### Step 2: Start the Server

**Option A - PowerShell (Recommended for Windows):**
```powershell
.\start-server.ps1
```

**Option B - Python:**
```bash
python -m http.server 8080
```

**Option C - Node.js:**
```bash
npx http-server -p 8080
```

### Step 3: Open Browser
The server will automatically open your browser to:
```
http://localhost:8080
```

If not, manually navigate to the URL above.

## 🎯 First Assessment

### 1. Click "Değerlendirmeye Başla"
From the landing page, click the blue button to start.

### 2. Fill Basic Information (Stage 1)
- **Change ID**: `CHG-2024-001` (example)
- **Description**: Brief change description
- **Class**: Select Class 1 or Class 2
- **Magnitude**: Minor or Major
- Fill remaining required fields (marked with *)

### 3. Login
Click "İleri" (Next) and enter your name when prompted.

### 4. Complete Details (Stage 2)
- Select justification matrix values
- Enter project count
- Fill impact assessments

### 5. Submit
Click "Değerlendirmeyi Tamamla" to see results!

## 🎨 Try Demo Scenarios

Visit the **Demo** page to load pre-configured scenarios:
1. **Fast-Track Simple** - Low risk, quick approval
2. **Fast-Track Complex** - Moderate risk
3. **Full-Track** - High risk, comprehensive review

Click "Senaryoyu Yükle" on any scenario to auto-fill the form.

## ⌨️ Keyboard Shortcuts

- `Ctrl + S` - Save draft
- `Ctrl + K` - Search (on history page)
- `Ctrl + /` - Show all shortcuts
- `Esc` - Close modals

## 💾 Data Storage

All data is stored locally in your browser:
- **LocalStorage** - Assessments and drafts
- **No server required** - Runs entirely offline
- **Export anytime** - CSV, PDF available

## 🌓 Dark Mode

Click the sun/moon icon in the header to toggle dark mode.

## 📱 Mobile Support

Fully responsive! Use on:
- Desktop browsers
- Tablets
- Mobile phones

## 🆘 Troubleshooting

### Server won't start
- Ensure port 8080 is not in use
- Try a different port: `.\start-server.ps1 -Port 8081`

### Page doesn't load
- Check browser console for errors (F12)
- Ensure JavaScript is enabled
- Try a different browser

### Data not saving
- Check LocalStorage is enabled
- Clear browser cache and try again
- Export data before clearing cache

### Dark mode not working
- Refresh the page
- Check browser supports CSS custom properties
- Try clearing LocalStorage

## 📚 Learn More

- Full documentation: [README.md](README.md)
- Feature list: [IMPROVEMENTS.md](IMPROVEMENTS.md)
- API docs: See inline code comments

## 🎓 Example Workflow

1. **Create Assessment** → Fill 2-stage form
2. **Review Score** → See real-time calculation
3. **Submit** → View detailed results
4. **Export** → Download PDF or CSV
5. **Email** → Share HTML template
6. **Archive** → Find in History page

## 🔐 Security Note

This is a **client-side only** application:
- No data sent to servers
- No user tracking
- No cookies required
- All processing in browser

Safe to use for sensitive change assessments!

## 🚀 Ready to Go!

You're all set! Start creating assessments and streamline your change management process.

**Happy assessing! 🎉**

---

Need help? Check [README.md](README.md) or open an issue on GitHub.
