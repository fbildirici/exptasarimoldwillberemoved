# ECA Tool - PowerShell Web Server
# Simple HTTP server for local development

param(
    [int]$Port = 8080,
    [string]$Path = $PSScriptRoot
)

Write-Host "================================" -ForegroundColor Cyan
Write-Host "  ECA Tool - Development Server" -ForegroundColor Cyan
Write-Host "================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Starting server on http://localhost:$Port" -ForegroundColor Green
Write-Host "Serving files from: $Path" -ForegroundColor Yellow
Write-Host "Press Ctrl+C to stop the server" -ForegroundColor Gray
Write-Host ""

# Create HTTP listener
$http = [System.Net.HttpListener]::new()
$http.Prefixes.Add("http://localhost:$Port/")
$http.Start()

if ($http.IsListening) {
    Write-Host "Server is running!" -ForegroundColor Green
    Write-Host "Open your browser: http://localhost:$Port" -ForegroundColor Cyan
    Write-Host ""

    # Try to open browser automatically
    try {
        Start-Process "http://localhost:$Port"
    } catch {
        Write-Host "Could not open browser automatically. Please open manually." -ForegroundColor Yellow
    }
}

# MIME types
$mimeTypes = @{
    '.html' = 'text/html'
    '.css'  = 'text/css'
    '.js'   = 'application/javascript'
    '.json' = 'application/json'
    '.png'  = 'image/png'
    '.jpg'  = 'image/jpeg'
    '.jpeg' = 'image/jpeg'
    '.gif'  = 'image/gif'
    '.svg'  = 'image/svg+xml'
    '.ico'  = 'image/x-icon'
    '.txt'  = 'text/plain'
    '.pdf'  = 'application/pdf'
    '.woff' = 'font/woff'
    '.woff2' = 'font/woff2'
    '.ttf'  = 'font/ttf'
    '.eot'  = 'application/vnd.ms-fontobject'
}

# Main server loop
while ($http.IsListening) {
    try {
        $context = $http.GetContext()
        $request = $context.Request
        $response = $context.Response

        $requestUrl = $request.Url.LocalPath
        Write-Host "$(Get-Date -Format 'HH:mm:ss') - " -NoNewline -ForegroundColor Gray
        Write-Host "$($request.HttpMethod) " -NoNewline -ForegroundColor Yellow
        Write-Host "$requestUrl" -ForegroundColor White

        # Default to index.html for root path
        if ($requestUrl -eq '/') {
            $requestUrl = '/index.html'
        }

        # Remove leading slash and construct file path
        $filePath = Join-Path $Path ($requestUrl.TrimStart('/'))

        # Handle data API endpoints
        if ($requestUrl -match '^/api/') {
            $apiPath = $requestUrl -replace '^/api/', ''

            switch ($apiPath) {
                'assessments' {
                    $dataFile = Join-Path $Path "data\assessments.json"
                    if (Test-Path $dataFile) {
                        $content = Get-Content $dataFile -Raw -Encoding UTF8
                        $response.ContentType = 'application/json'
                        $buffer = [System.Text.Encoding]::UTF8.GetBytes($content)
                        $response.ContentLength64 = $buffer.Length
                        $response.OutputStream.Write($buffer, 0, $buffer.Length)
                    } else {
                        $response.StatusCode = 404
                    }
                }
                default {
                    $response.StatusCode = 404
                }
            }
        }
        # Serve static files
        elseif (Test-Path $filePath -PathType Leaf) {
            $content = [System.IO.File]::ReadAllBytes($filePath)
            $extension = [System.IO.Path]::GetExtension($filePath)

            # Set content type
            if ($mimeTypes.ContainsKey($extension)) {
                $response.ContentType = $mimeTypes[$extension]
            } else {
                $response.ContentType = 'application/octet-stream'
            }

            # Add UTF-8 charset for text files
            if ($extension -in @('.html', '.css', '.js', '.json', '.txt', '.svg')) {
                $response.ContentType += '; charset=utf-8'
            }

            $response.ContentLength64 = $content.Length
            $response.OutputStream.Write($content, 0, $content.Length)
        }
        # File not found
        else {
            $response.StatusCode = 404
            $notFoundHtml = @"
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>404 - Not Found</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; padding: 50px; background: linear-gradient(135deg, #003080, #002060); color: white; }
        h1 { font-size: 72px; margin: 0; }
        p { font-size: 24px; }
        a { color: #4a90e2; text-decoration: none; }
    </style>
</head>
<body>
    <h1>404</h1>
    <p>Sayfa bulunamadı</p>
    <p><a href="/">Ana sayfaya dön</a></p>
</body>
</html>
"@
            $buffer = [System.Text.Encoding]::UTF8.GetBytes($notFoundHtml)
            $response.ContentType = 'text/html; charset=utf-8'
            $response.ContentLength64 = $buffer.Length
            $response.OutputStream.Write($buffer, 0, $buffer.Length)

            Write-Host "    → 404 Not Found" -ForegroundColor Red
        }

        $response.Close()
    }
    catch {
        if ($_.Exception.InnerException -and $_.Exception.InnerException.Message -like "*operation was canceled*") {
            # Server is shutting down
            break
        }
        Write-Host "Error: $_" -ForegroundColor Red
    }
}

# Cleanup
$http.Stop()
$http.Close()
Write-Host ""
Write-Host "Server stopped." -ForegroundColor Yellow
