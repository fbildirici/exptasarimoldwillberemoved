# ECA Tool (Enterprise Change Assessment)

Modern, web-based enterprise change management assessment tool with intelligent risk analysis and automated track recommendations.

![ECA Tool](https://img.shields.io/badge/version-2.0.0-blue)
![License](https://img.shields.io/badge/license-MIT-green)

## 🎯 Overview

**ECA Tool** is a comprehensive change management assessment platform that helps organizations evaluate, categorize, and track changes through intelligent algorithms. The system analyzes 12 different criteria to automatically recommend the most appropriate approval track: Fast-Track Simple, Fast-Track Complex, or Full-Track.

## ✨ Features

### Core Functionality
- **2-Stage Assessment Process**
  - Stage 1: Change Specialist Review (no authentication required)
  - Stage 2: Detailed Review (authentication required)

- **Intelligent Scoring Algorithm**
  - 12 evaluation criteria with weighted scoring
  - Automatic Full-Track triggers for critical changes
  - Real-time score calculation and visualization

- **Three Track System**
  - **Fast-Track Simple** (0-39 points): Low risk, quick approval
  - **Fast-Track Complex** (40-69 points): Moderate risk, standard process
  - **Full-Track** (70-100 points): High risk, comprehensive evaluation

### User Experience
- **Modern UI/UX**
  - Clean, responsive design
  - Dark mode support
  - Smooth animations and transitions
  - Mobile-first approach

- **Auto-Save & Draft Management**
  - Auto-save every 30 seconds
  - Manual save with Ctrl+S
  - Resume drafts anytime

- **Accessibility**
  - Keyboard shortcuts (Ctrl+K, Ctrl+/, etc.)
  - ARIA labels and semantic HTML
  - Screen reader compatible

### Data Management
- **Export Options**
  - PDF export (print to PDF)
  - CSV export (single or bulk)
  - Email template generation

- **History & Search**
  - Searchable assessment history
  - Draft management
  - Filtering and sorting

## 🚀 Getting Started

### Prerequisites
- Modern web browser (Chrome, Firefox, Edge, Safari)
- PowerShell (Windows) or any HTTP server for hosting

### Installation

1. **Clone or download the repository**
   ```bash
   cd ECATOOL
   ```

2. **Start the development server**

   **Windows (PowerShell):**
   ```powershell
   .\start-server.ps1
   ```

   **Alternative (Python):**
   ```bash
   python -m http.server 8080
   ```

   **Alternative (Node.js):**
   ```bash
   npx http-server -p 8080
   ```

3. **Open your browser**
   ```
   http://localhost:8080
   ```

## 📋 Usage

### Creating an Assessment

1. **Navigate to Assessment Page**
   - Click "Değerlendirmeye Başla" or go to `/assessment.html`

2. **Fill Stage 1: Change Specialist Review**
   - Change ID (required)
   - Change Description
   - Change Class (Class 1 / Class 2)
   - Change Magnitude (Minor / Major)
   - Customer Request
   - Delivery Impact
   - Infrastructure Requirements

3. **Login** (for Stage 2)
   - Click "İleri" to proceed
   - Enter your name when prompted

4. **Fill Stage 2: Detail Review**
   - Justification Matrix (7 categories)
   - Project Count
   - Side Effects
   - Customer Documentation Impact
   - And more...

5. **Submit Assessment**
   - Review live score
   - Click "Değerlendirmeyi Tamamla"
   - View results page

### Scoring Algorithm

The system evaluates 12 criteria:

| Criteria | Points | Auto Full-Track |
|----------|--------|----------------|
| Change Class | 5-10 | Class 1 → Yes |
| Change Magnitude | 2-5 | - |
| Delivery Impact | 0-10 | Significant → Yes |
| Test Infrastructure | 2-5 | - |
| Production Infrastructure | 2-5 | - |
| Justification Matrix | 0-15 (1.5x) | Critical + Customer → Yes |
| Project Count | 0-5 | 5+ → Yes |
| Side Effect | 1-3 | - |
| Customer Document | 1-5 | - |
| DK Delivery | 2-10 | - |
| Open Order | 0-5 | Critical + Order → Yes |
| Purchase Order | 0-5 | - |

**Track Recommendations:**
- **0-39 points**: Fast-Track Simple
- **40-69 points**: Fast-Track Complex
- **70-100 points**: Full-Track
- **Auto triggers**: Immediate Full-Track regardless of score

## 🎨 Technology Stack

### Frontend
- **HTML5** - Semantic markup
- **CSS3** - Custom properties, Grid, Flexbox
- **Vanilla JavaScript (ES6+)** - No frameworks, pure JS

### Styling
- **Google Fonts**: Inter (300-800) & Poppins (600-700)
- **SVG Icons**: Inline SVGs for performance
- **Design System**: CSS custom properties for theming

### Data Storage
- **LocalStorage**: Client-side persistence
- **JSON**: Data export/import format

### Server
- **PowerShell HTTP Listener**: Lightweight development server
- Alternative: Any HTTP server (Python, Node.js, nginx, etc.)

## 📁 Project Structure

```
ECATOOL/
├── index.html                 # Landing page
├── assessment.html            # Assessment form
├── history.html               # History & drafts
├── results.html               # Results page
├── demo.html                  # Demo scenarios
├── start-server.ps1           # PowerShell server
├── README.md                  # Documentation
├── IMPROVEMENTS.md            # v2.0 improvements
│
├── assets/
│   ├── css/
│   │   ├── style.css          # Main styles (2000+ lines)
│   │   ├── assessment.css     # Assessment-specific styles
│   │   └── toast.css          # Toast notifications
│   │
│   ├── js/
│   │   ├── app.js             # Main app logic
│   │   ├── assessment.js      # Assessment engine (1170 lines)
│   │   ├── history.js         # History management (660 lines)
│   │   ├── results.js         # Results visualization (550 lines)
│   │   ├── auth.js            # Authentication
│   │   ├── animations.js      # Scroll animations
│   │   │
│   │   └── utils/
│   │       ├── toast.js       # Toast system
│   │       ├── helpers.js     # Utility functions
│   │       ├── darkMode.js    # Dark mode toggle
│   │       └── shortcuts.js   # Keyboard shortcuts
│   │
│   └── img/
│       └── (SVG assets)
│
└── data/
    └── assessments.json       # Data storage
```

## ⌨️ Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Ctrl + K` | Focus search |
| `Ctrl + /` | Show shortcuts help |
| `Ctrl + H` | Go to home |
| `Ctrl + N` | New assessment |
| `Ctrl + L` | View history |
| `Ctrl + S` | Save draft |
| `Ctrl + Enter` | Submit form |
| `Esc` | Close modals |

## 🎯 Key Features Detail

### 1. Auto-Save System
- Saves progress every 30 seconds
- Visual indicator on save
- Resume from drafts anytime
- No data loss on browser crash

### 2. Dark Mode
- System preference detection
- Persistent user choice
- Smooth transitions
- All pages supported

### 3. Real-Time Scoring
- Live score calculation
- Visual progress bars
- Instant feedback
- Track recommendation updates

### 4. Export Options
- **PDF**: Print-friendly layout
- **CSV**: Data analysis
- **Email**: HTML template with branding

### 5. Responsive Design
- Mobile-first approach
- Touch-friendly interfaces
- Adaptive layouts
- Progressive enhancement

## 🔒 Security

### XSS Protection
- All user input is sanitized
- HTML escaping on output
- Content Security Policy ready

### Data Privacy
- Client-side storage only
- No server-side persistence
- User data stays local
- Easy data export/deletion

## 🌐 Browser Support

| Browser | Version |
|---------|---------|
| Chrome | 90+ |
| Firefox | 88+ |
| Edge | 90+ |
| Safari | 14+ |

## 📊 Performance

- **Page Load**: < 1s (on fast connection)
- **First Contentful Paint**: < 0.5s
- **Time to Interactive**: < 1.5s
- **No external dependencies** (except Google Fonts)

## 🛠️ Development

### Running in Development Mode

```powershell
# Start server
.\start-server.ps1

# Server runs on http://localhost:8080
# Auto-opens browser
# Ctrl+C to stop
```

### Building for Production

The application is static and requires no build step:

1. Copy all files to web server
2. Ensure MIME types are configured
3. Enable HTTPS (recommended)
4. Configure CSP headers (optional)

### Customization

#### Changing Colors
Edit CSS custom properties in `assets/css/style.css`:

```css
:root {
    --navy-primary: #003080;  /* Your brand color */
    --success-primary: #2ecc40;
    /* ... */
}
```

#### Adjusting Scoring
Modify scoring logic in `assets/js/assessment.js`:

```javascript
// Line ~100
if (this.formData.changeClass === 'class1') {
    totalScore += 10; // Adjust points
}
```

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📧 Support

For support, please open an issue in the repository or contact the development team.

## 🙏 Acknowledgments

- Design inspired by modern enterprise tools
- Icons and fonts from Google Fonts
- Community feedback and testing

## 📈 Roadmap

See [IMPROVEMENTS.md](IMPROVEMENTS.md) for planned features and enhancements.

---

**Made with ❤️ for better change management**

Version 2.0.0 | © 2026 ECA Tool
