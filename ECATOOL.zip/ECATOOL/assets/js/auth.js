/**
 * Simple Authentication System
 * Mock authentication for demo purposes
 */

class AuthManager {
    constructor() {
        this.currentUser = null;
        this.init();
    }

    init() {
        // Load saved user
        const savedUser = localStorage.getItem('ecaUser');
        if (savedUser) {
            this.currentUser = JSON.parse(savedUser);
            this.updateUI();
        }

        // Listen for login requests
        window.addEventListener('showLogin', () => this.showLoginPrompt());

        // Update avatar on all pages
        this.updateUI();
    }

    showLoginPrompt() {
        const name = prompt('Lütfen adınızı girin:');
        if (name && name.trim()) {
            this.login(name.trim());
        }
    }

    login(name) {
        const user = {
            name: name,
            initials: this.getInitials(name),
            loginTime: new Date().toISOString()
        };

        this.currentUser = user;
        localStorage.setItem('ecaUser', JSON.stringify(user));
        this.updateUI();

        // Dispatch auth state change event
        window.dispatchEvent(new CustomEvent('authStateChanged', {
            detail: { isAuthenticated: true, user }
        }));

        showToast('success', 'Giriş Başarılı', `Hoş geldiniz, ${name}!`);
    }

    logout() {
        this.currentUser = null;
        localStorage.removeItem('ecaUser');
        this.updateUI();

        window.dispatchEvent(new CustomEvent('authStateChanged', {
            detail: { isAuthenticated: false, user: null }
        }));

        showToast('info', 'Çıkış Yapıldı', 'Başarıyla çıkış yaptınız');
    }

    getInitials(name) {
        const words = name.trim().split(' ');
        if (words.length >= 2) {
            return (words[0][0] + words[words.length - 1][0]).toUpperCase();
        }
        return name.substring(0, 2).toUpperCase();
    }

    updateUI() {
        const avatar = document.getElementById('userAvatar');
        const initialsElement = document.getElementById('userInitials');

        if (avatar && initialsElement) {
            if (this.currentUser) {
                initialsElement.textContent = this.currentUser.initials;
                avatar.title = this.currentUser.name;
                avatar.style.cursor = 'pointer';

                // Add click handler for logout
                avatar.onclick = () => {
                    if (confirm('Çıkış yapmak istediğinizden emin misiniz?')) {
                        this.logout();
                    }
                };
            } else {
                initialsElement.textContent = '?';
                avatar.title = 'Giriş Yap';
                avatar.style.cursor = 'pointer';

                avatar.onclick = () => this.showLoginPrompt();
            }
        }
    }

    isAuthenticated() {
        return this.currentUser !== null;
    }

    getCurrentUser() {
        return this.currentUser;
    }
}

// Helper function for other modules
function getCurrentUser() {
    const savedUser = localStorage.getItem('ecaUser');
    return savedUser ? JSON.parse(savedUser) : null;
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    window.authManager = new AuthManager();
});
