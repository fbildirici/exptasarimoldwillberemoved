/**
 * Results Page
 * Display assessment results with visualizations
 */

class ResultsViewer {
    constructor() {
        this.assessment = null;
        this.init();
    }

    init() {
        const assessmentId = getUrlParam('id');
        if (!assessmentId) {
            showToast('error', 'Hata', 'Değerlendirme bulunamadı');
            setTimeout(() => {
                window.location.href = 'history.html';
            }, 2000);
            return;
        }

        this.loadAssessment(assessmentId);
    }

    loadAssessment(id) {
        const assessments = getFromStorage('ecaAssessments', []);
        this.assessment = assessments.find(a => a.id === id);

        if (!this.assessment) {
            showToast('error', 'Hata', 'Değerlendirme bulunamadı');
            setTimeout(() => {
                window.location.href = 'history.html';
            }, 2000);
            return;
        }

        this.renderResults();
        this.setupActions();
    }

    renderResults() {
        const { score, track, data, breakdown, autoFullTrack, autoFullTrackReason } = this.assessment;

        // Update score circle
        this.animateScoreCircle(score);

        // Update recommendation badge
        this.renderRecommendationBadge(track, autoFullTrack, autoFullTrackReason);

        // Update details
        this.renderDetails(data);

        // Update score breakdown
        this.renderScoreBreakdown(breakdown);

        // Update next steps
        this.renderNextSteps(track);
    }

    animateScoreCircle(score) {
        const scoreElement = document.getElementById('finalScore');
        const progressCircle = document.getElementById('scoreProgress');

        // Animate number
        let current = 0;
        const duration = 1500;
        const increment = score / (duration / 16);

        const timer = setInterval(() => {
            current += increment;
            if (current >= score) {
                current = score;
                clearInterval(timer);
            }
            scoreElement.textContent = Math.round(current);
        }, 16);

        // Animate circle
        const circumference = 2 * Math.PI * 90; // radius = 90
        const offset = circumference - (score / 100) * circumference;

        setTimeout(() => {
            progressCircle.style.strokeDashoffset = offset;
            progressCircle.style.transition = 'stroke-dashoffset 1.5s ease-in-out';
        }, 100);
    }

    renderRecommendationBadge(track, autoFullTrack, reason) {
        const badgeContainer = document.getElementById('recommendationBadge');

        const trackConfig = {
            simple: {
                color: '#2ecc40',
                bg: '#d4edda',
                label: 'Fast-Track Simple',
                icon: '⚡'
            },
            complex: {
                color: '#ff9800',
                bg: '#fff3cd',
                label: 'Fast-Track Complex',
                icon: '🔍'
            },
            full: {
                color: '#e53935',
                bg: '#f8d7da',
                label: 'Full-Track',
                icon: '⚠️'
            }
        };

        const config = trackConfig[track];

        badgeContainer.innerHTML = `
            <div style="display: inline-block; padding: 12px 24px; background: ${config.bg};
                        color: ${config.color}; border-radius: 24px; font-size: 1.25rem; font-weight: 700;">
                ${config.icon} ${config.label}
            </div>
            ${autoFullTrack ? `
                <div style="margin-top: 12px; padding: 12px; background: #fff3cd; border-left: 4px solid #ff9800;
                            border-radius: 4px; font-size: 0.875rem;">
                    <strong>Otomatik Full-Track:</strong> ${escapeHtml(reason)}
                </div>
            ` : ''}
        `;
    }

    renderDetails(data) {
        document.getElementById('changeId').textContent = data.changeId || '-';
        document.getElementById('changeDescription').textContent = data.changeDescription || '-';
        document.getElementById('changeClass').textContent = data.changeClass === 'class1' ? 'Sınıf 1' : 'Sınıf 2';
        document.getElementById('changeMagnitude').textContent = data.changeMagnitude === 'major' ? 'Major' : 'Minor';
        document.getElementById('customerRequest').textContent = data.customerRequest === 'yes' ? 'Evet' : 'Hayır';
        document.getElementById('projectCount').textContent = this.getProjectCountLabel(data.projectCount);
        document.getElementById('assessmentDate').textContent = formatDate(this.assessment.timestamp);
    }

    getProjectCountLabel(count) {
        if (!count) return '-';
        const labels = {
            '1': '1 proje',
            '2-4': '2-4 proje',
            '5+': '5+ proje'
        };
        return labels[count] || count;
    }

    renderScoreBreakdown(breakdown) {
        const container = document.getElementById('scoreBreakdown');

        if (!breakdown || breakdown.length === 0) {
            container.innerHTML = '<p>Puan detayları mevcut değil</p>';
            return;
        }

        container.innerHTML = breakdown.map(item => `
            <div class="score-item">
                <div class="score-item-label">${escapeHtml(item.label)}</div>
                <div class="score-item-bar">
                    <div class="score-item-fill" style="width: ${(item.points / item.max) * 100}%"></div>
                </div>
                <div class="score-item-value">${item.points} / ${item.max}</div>
            </div>
        `).join('');

        // Add total
        const total = breakdown.reduce((sum, item) => sum + item.points, 0);
        const maxTotal = breakdown.reduce((sum, item) => sum + item.max, 0);

        container.innerHTML += `
            <div class="score-item" style="margin-top: 16px; padding-top: 16px; border-top: 2px solid var(--gray-300);">
                <div class="score-item-label" style="font-weight: 700;">Toplam</div>
                <div class="score-item-bar">
                    <div class="score-item-fill" style="width: ${(total / maxTotal) * 100}%; background: linear-gradient(90deg, #003080, #778fbc);"></div>
                </div>
                <div class="score-item-value" style="font-weight: 700; font-size: 1.125rem;">${total} / ${maxTotal}</div>
            </div>
        `;
    }

    renderNextSteps(track) {
        const container = document.getElementById('nextSteps');

        const steps = {
            simple: [
                {
                    title: 'Hızlı Onay Süreci',
                    description: 'Change Specialist onayı ile işlem başlatılabilir'
                },
                {
                    title: 'Minimal Dokümentasyon',
                    description: 'Standart değişiklik formu yeterlidir'
                },
                {
                    title: 'Test Süreci',
                    description: 'Basit test senaryoları ile devam edilebilir'
                },
                {
                    title: 'Uygulama',
                    description: 'Onay sonrası 1-2 gün içinde uygulanabilir'
                }
            ],
            complex: [
                {
                    title: 'Standart Değerlendirme',
                    description: 'İlgili departmanlardan onay alınmalıdır'
                },
                {
                    title: 'Detaylı Dokümentasyon',
                    description: 'Etki analizi ve risk değerlendirmesi gereklidir'
                },
                {
                    title: 'Kapsamlı Test',
                    description: 'Tüm etkilenen sistemler test edilmelidir'
                },
                {
                    title: 'Planlı Uygulama',
                    description: 'Onay sonrası 3-5 gün içinde uygulanabilir'
                }
            ],
            full: [
                {
                    title: 'Tam Değerlendirme Süreci',
                    description: 'Change Advisory Board (CAB) toplantısına sunulmalıdır'
                },
                {
                    title: 'Kapsamlı Dokümentasyon',
                    description: 'Detaylı etki analizi, risk değerlendirmesi ve geri alma planı hazırlanmalıdır'
                },
                {
                    title: 'Tam Test Döngüsü',
                    description: 'Tüm test aşamaları (unit, integration, system, UAT) tamamlanmalıdır'
                },
                {
                    title: 'Onay ve Planlama',
                    description: 'CAB onayı sonrası bakım penceresi planlanmalıdır'
                },
                {
                    title: 'İzleme ve Gözden Geçirme',
                    description: 'Uygulama sonrası izleme ve post-implementation review yapılmalıdır'
                }
            ]
        };

        const trackSteps = steps[track] || steps.full;

        container.innerHTML = trackSteps.map((step, index) => `
            <div class="next-step-item">
                <div class="next-step-icon">${index + 1}</div>
                <div class="next-step-content">
                    <h4>${escapeHtml(step.title)}</h4>
                    <p>${escapeHtml(step.description)}</p>
                </div>
            </div>
        `).join('');
    }

    setupActions() {
        // CSV Export
        document.getElementById('exportCsvBtn').addEventListener('click', () => {
            this.exportCsv();
        });

        // Share button
        document.getElementById('shareBtn').addEventListener('click', () => {
            this.shareResults();
        });
    }

    exportCsv() {
        const { score, track, data } = this.assessment;

        const csvData = [{
            'Değişiklik ID': data.changeId || '-',
            'Açıklama': data.changeDescription || '-',
            'Tarih': formatDate(this.assessment.timestamp),
            'Puan': score,
            'Öneri': track === 'simple' ? 'Fast-Track Simple' : track === 'complex' ? 'Fast-Track Complex' : 'Full-Track',
            'Sınıf': data.changeClass === 'class1' ? 'Sınıf 1' : 'Sınıf 2',
            'Büyüklük': data.changeMagnitude === 'major' ? 'Major' : 'Minor',
            'Müşteri Talebi': data.customerRequest === 'yes' ? 'Evet' : 'Hayır'
        }];

        exportToCsv(csvData, `assessment-${this.assessment.id}.csv`);
    }

    shareResults() {
        const url = window.location.href;
        if (navigator.share) {
            navigator.share({
                title: 'ECA Değerlendirme Sonucu',
                text: `Değerlendirme Puanı: ${this.assessment.score}`,
                url: url
            }).catch(err => {
                console.log('Share failed:', err);
                this.fallbackShare(url);
            });
        } else {
            this.fallbackShare(url);
        }
    }

    fallbackShare(url) {
        copyToClipboard(url);
        showToast('success', 'Link Kopyalandı', 'Sonuç linki panoya kopyalandı');
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    new ResultsViewer();
});
