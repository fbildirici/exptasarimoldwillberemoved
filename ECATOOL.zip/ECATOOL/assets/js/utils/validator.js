/**
 * Form Validation Utilities
 * Client-side validation helpers
 */

class FormValidator {
    constructor(formElement) {
        this.form = formElement;
        this.errors = {};
    }

    // Validate required fields
    validateRequired(fieldName, value) {
        if (!value || value.trim() === '') {
            this.errors[fieldName] = 'Bu alan zorunludur';
            return false;
        }
        return true;
    }

    // Validate email format
    validateEmail(fieldName, value) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(value)) {
            this.errors[fieldName] = 'Geçerli bir e-posta adresi girin';
            return false;
        }
        return true;
    }

    // Validate minimum length
    validateMinLength(fieldName, value, minLength) {
        if (value.length < minLength) {
            this.errors[fieldName] = `En az ${minLength} karakter olmalıdır`;
            return false;
        }
        return true;
    }

    // Validate maximum length
    validateMaxLength(fieldName, value, maxLength) {
        if (value.length > maxLength) {
            this.errors[fieldName] = `En fazla ${maxLength} karakter olmalıdır`;
            return false;
        }
        return true;
    }

    // Validate number range
    validateRange(fieldName, value, min, max) {
        const num = Number(value);
        if (isNaN(num) || num < min || num > max) {
            this.errors[fieldName] = `${min} ile ${max} arasında bir değer girin`;
            return false;
        }
        return true;
    }

    // Validate pattern match
    validatePattern(fieldName, value, pattern, message) {
        if (!pattern.test(value)) {
            this.errors[fieldName] = message || 'Geçersiz format';
            return false;
        }
        return true;
    }

    // Show validation errors
    showErrors() {
        Object.keys(this.errors).forEach(fieldName => {
            const field = this.form.querySelector(`[name="${fieldName}"]`);
            if (field) {
                this.showFieldError(field, this.errors[fieldName]);
            }
        });
    }

    // Show error for specific field
    showFieldError(field, message) {
        // Remove existing error
        this.clearFieldError(field);

        // Add error class
        field.classList.add('has-error');

        // Create error message element
        const errorElement = document.createElement('div');
        errorElement.className = 'field-error';
        errorElement.textContent = message;
        errorElement.style.color = 'var(--error-primary)';
        errorElement.style.fontSize = 'var(--text-xs)';
        errorElement.style.marginTop = 'var(--space-1)';

        // Insert after field
        field.parentNode.insertBefore(errorElement, field.nextSibling);
    }

    // Clear field error
    clearFieldError(field) {
        field.classList.remove('has-error');
        const existingError = field.parentNode.querySelector('.field-error');
        if (existingError) {
            existingError.remove();
        }
    }

    // Clear all errors
    clearAllErrors() {
        this.errors = {};
        this.form.querySelectorAll('.has-error').forEach(field => {
            this.clearFieldError(field);
        });
    }

    // Check if form is valid
    isValid() {
        return Object.keys(this.errors).length === 0;
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { FormValidator };
}
