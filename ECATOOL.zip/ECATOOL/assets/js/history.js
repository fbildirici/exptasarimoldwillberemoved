/**
 * History and Drafts Management
 * View, search, export, and manage assessments
 */

class HistoryManager {
    constructor() {
        this.currentTab = 'completed';
        this.assessments = [];
        this.drafts = [];
        this.currentDeleteId = null;
        this.init();
    }

    init() {
        this.loadData();
        this.setupTabs();
        this.setupSearch();
        this.setupActions();
        this.renderCompleted();
        this.renderDrafts();
    }

    loadData() {
        this.assessments = getFromStorage('ecaAssessments', []);
        this.drafts = getFromStorage('ecaDrafts', []);
        this.updateCounts();
    }

    updateCounts() {
        document.getElementById('completedCount').textContent = this.assessments.length;
        document.getElementById('draftsCount').textContent = this.drafts.length;
    }

    setupTabs() {
        document.querySelectorAll('.history-tabs .tab-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const tab = btn.dataset.tab;
                this.switchTab(tab);
            });
        });
    }

    switchTab(tab) {
        this.currentTab = tab;

        // Update tab buttons
        document.querySelectorAll('.history-tabs .tab-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tab === tab);
        });

        // Update tab content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.toggle('active', content.dataset.tab === tab);
        });
    }

    setupSearch() {
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.addEventListener('input', debounce((e) => {
                this.searchAssessments(e.target.value);
            }, 300));
        }
    }

    searchAssessments(query) {
        const filtered = this.assessments.filter(a => {
            const searchStr = `${a.id} ${a.data.changeId} ${a.data.changeDescription}`.toLowerCase();
            return searchStr.includes(query.toLowerCase());
        });

        this.renderCompleted(filtered);
    }

    setupActions() {
        // Export All
        const exportAllBtn = document.getElementById('exportAllBtn');
        if (exportAllBtn) {
            exportAllBtn.addEventListener('click', () => this.exportAll());
        }

        // Import CSV
        const importBtn = document.getElementById('importCsvBtn');
        const fileInput = document.getElementById('csvFileInput');

        if (importBtn && fileInput) {
            importBtn.addEventListener('click', () => fileInput.click());
            fileInput.addEventListener('change', (e) => this.importCsv(e));
        }
    }

    renderCompleted(data = this.assessments) {
        const cardsGrid = document.getElementById('completedCardsGrid');
        const emptyState = document.getElementById('completedEmpty');

        if (data.length === 0) {
            cardsGrid.innerHTML = '';
            emptyState.style.display = 'block';
            return;
        }

        emptyState.style.display = 'none';

        // Sort by date (newest first)
        const sorted = [...data].sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

        cardsGrid.innerHTML = sorted.map(assessment => {
            const circumference = 2 * Math.PI * 27;
            const offset = circumference - (assessment.score / 100) * circumference;

            return `
            <div class="assessment-card">
                <div class="assessment-card-header">
                    <div class="assessment-card-id">${escapeHtml(assessment.data.changeId || assessment.id)}</div>
                    <div class="assessment-card-date">${formatDate(assessment.timestamp)}</div>
                </div>
                <div class="assessment-card-description">${escapeHtml(assessment.data.changeDescription || '-')}</div>
                <div class="assessment-card-score">
                    <div class="score-circle-mini">
                        <svg viewBox="0 0 60 60">
                            <circle class="score-bg" cx="30" cy="30" r="27" stroke-dasharray="${circumference}" stroke-dashoffset="0"/>
                            <circle class="score-progress" cx="30" cy="30" r="27" stroke-dasharray="${circumference}" stroke-dashoffset="${offset}"/>
                        </svg>
                        <div class="score-text">${assessment.score}</div>
                    </div>
                    <div class="score-info">
                        <div class="score-label">Önerilen Track</div>
                        <div class="score-track ${assessment.track}">
                            ${assessment.track === 'simple' ? 'Fast-Track Simple' : assessment.track === 'complex' ? 'Fast-Track Complex' : 'Full-Track'}
                        </div>
                    </div>
                </div>
                <div class="assessment-card-actions">
                    <button class="card-action-btn" onclick="window.historyManager.viewAssessment('${assessment.id}')" title="Görüntüle">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                            <circle cx="12" cy="12" r="3"/>
                        </svg>
                        Görüntüle
                    </button>
                    <button class="card-action-btn" onclick="window.historyManager.exportSingle('${assessment.id}')" title="CSV Export">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/>
                            <polyline points="7 10 12 15 17 10"/>
                            <line x1="12" y1="15" x2="12" y2="3"/>
                        </svg>
                        CSV
                    </button>
                    <button class="card-action-btn" onclick="window.historyManager.showMailPreview('${assessment.id}')" title="Mail Önizleme">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                            <polyline points="22,6 12,13 2,6"/>
                        </svg>
                        Mail
                    </button>
                    <button class="card-action-btn danger" onclick="window.historyManager.deleteAssessment('${assessment.id}')" title="Sil">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="3 6 5 6 21 6"/>
                            <path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/>
                        </svg>
                        Sil
                    </button>
                </div>
            </div>
        `}).join('');
    }

    getTrackBadge(track) {
        const badges = {
            simple: '<span class="badge" style="background: #d4edda; color: #218838; padding: 4px 12px; border-radius: 12px; font-size: 0.75rem; font-weight: 600;">Fast-Track Simple</span>',
            complex: '<span class="badge" style="background: #fff3cd; color: #856404; padding: 4px 12px; border-radius: 12px; font-size: 0.75rem; font-weight: 600;">Fast-Track Complex</span>',
            full: '<span class="badge" style="background: #f8d7da; color: #b71c1c; padding: 4px 12px; border-radius: 12px; font-size: 0.75rem; font-weight: 600;">Full-Track</span>'
        };
        return badges[track] || '';
    }

    renderDrafts() {
        const grid = document.getElementById('draftsGrid');
        const emptyState = document.getElementById('draftsEmpty');

        if (this.drafts.length === 0) {
            grid.innerHTML = '';
            emptyState.style.display = 'block';
            return;
        }

        emptyState.style.display = 'none';

        // Sort by timestamp (newest first)
        const sorted = [...this.drafts].sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

        grid.innerHTML = sorted.map(draft => `
            <div class="draft-card">
                <div class="draft-badge">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M12 20h9"/>
                        <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/>
                    </svg>
                    Taslak
                </div>
                <div class="assessment-card-header">
                    <div class="assessment-card-id">${escapeHtml(draft.data.changeId || 'ID Girilmedi')}</div>
                    <div class="assessment-card-date">${getRelativeTime(draft.timestamp)}</div>
                </div>
                <div class="assessment-card-description">${escapeHtml(draft.data.changeDescription || 'Açıklama henüz girilmedi')}</div>
                <div class="assessment-card-actions">
                    <button class="card-action-btn" onclick="window.historyManager.continueDraft('${draft.id}')">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polygon points="5 3 19 12 5 21 5 3"/>
                        </svg>
                        Devam Et
                    </button>
                    <button class="card-action-btn danger" onclick="window.historyManager.deleteDraft('${draft.id}')">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="3 6 5 6 21 6"/>
                            <path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/>
                        </svg>
                        Sil
                    </button>
                </div>
            </div>
        `).join('');
    }

    viewAssessment(id) {
        window.location.href = `results.html?id=${id}`;
    }

    exportSingle(id) {
        const assessment = this.assessments.find(a => a.id === id);
        if (!assessment) return;

        const data = [{
            'Değişiklik ID': assessment.data.changeId || assessment.id,
            'Açıklama': assessment.data.changeDescription || '',
            'Tarih': formatDate(assessment.timestamp),
            'Puan': assessment.score,
            'Öneri': assessment.track === 'simple' ? 'Fast-Track Simple' : assessment.track === 'complex' ? 'Fast-Track Complex' : 'Full-Track',
            'Sınıf': assessment.data.changeClass === 'class1' ? 'Sınıf 1' : 'Sınıf 2',
            'Büyüklük': assessment.data.changeMagnitude === 'major' ? 'Major' : 'Minor'
        }];

        exportToCsv(data, `assessment-${assessment.id}.csv`);
    }

    exportAll() {
        if (this.assessments.length === 0) {
            showToast('warning', 'Uyarı', 'Dışa aktarılacak değerlendirme bulunamadı');
            return;
        }

        const data = this.assessments.map(a => ({
            'Değişiklik ID': a.data.changeId || a.id,
            'Açıklama': a.data.changeDescription || '',
            'Tarih': formatDate(a.timestamp),
            'Puan': a.score,
            'Öneri': a.track === 'simple' ? 'Fast-Track Simple' : a.track === 'complex' ? 'Fast-Track Complex' : 'Full-Track',
            'Sınıf': a.data.changeClass === 'class1' ? 'Sınıf 1' : 'Sınıf 2',
            'Büyüklük': a.data.changeMagnitude === 'major' ? 'Major' : 'Minor',
            'Müşteri Talebi': a.data.customerRequest === 'yes' ? 'Evet' : 'Hayır'
        }));

        exportToCsv(data, `eca-assessments-${new Date().toISOString().split('T')[0]}.csv`);
    }

    importCsv(e) {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (event) => {
            try {
                const csvData = parseCsv(event.target.result);
                // Process and validate CSV data
                showToast('success', 'Başarılı', `${csvData.length} kayıt içe aktarıldı`);
                this.loadData();
                this.renderCompleted();
            } catch (error) {
                showToast('error', 'Hata', 'CSV dosyası işlenirken hata oluştu');
                console.error('CSV Import Error:', error);
            }
        };
        reader.readAsText(file);
        e.target.value = ''; // Reset input
    }

    showMailPreview(id) {
        const assessment = this.assessments.find(a => a.id === id);
        if (!assessment) return;

        const modal = document.getElementById('mailPreviewModal');
        const content = document.getElementById('mailPreviewContent');

        content.innerHTML = generateEmailHtml(assessment);

        modal.classList.add('show');

        // Copy HTML button
        document.getElementById('copyEmailHtml').onclick = () => {
            copyToClipboard(content.innerHTML);
        };

        // Open Outlook button
        document.getElementById('openMailto').onclick = () => {
            const subject = `ECA Değerlendirme: ${assessment.data.changeId}`;
            const body = `Değerlendirme sonucu: ${assessment.score} puan - ${assessment.track}`;
            window.location.href = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
        };
    }

    deleteAssessment(id) {
        this.currentDeleteId = id;
        const modal = document.getElementById('deleteModal');
        modal.classList.add('show');

        document.getElementById('confirmDeleteBtn').onclick = () => {
            this.confirmDelete();
        };
    }

    confirmDelete() {
        if (!this.currentDeleteId) return;

        this.assessments = this.assessments.filter(a => a.id !== this.currentDeleteId);
        saveToStorage('ecaAssessments', this.assessments);

        showToast('success', 'Silindi', 'Değerlendirme başarıyla silindi');

        this.loadData();
        this.renderCompleted();
        this.closeDeleteModal();
    }

    closeDeleteModal() {
        document.getElementById('deleteModal').classList.remove('show');
        this.currentDeleteId = null;
    }

    continueDraft(id) {
        window.location.href = `assessment.html?draft=${id}`;
    }

    deleteDraft(id) {
        if (confirm('Bu taslağı silmek istediğinizden emin misiniz?')) {
            this.drafts = this.drafts.filter(d => d.id !== id);
            saveToStorage('ecaDrafts', this.drafts);
            showToast('success', 'Silindi', 'Taslak başarıyla silindi');
            this.loadData();
            this.renderDrafts();
        }
    }
}

// Global functions for onclick handlers
function closeMailModal() {
    document.getElementById('mailPreviewModal').classList.remove('show');
}

function closeDeleteModal() {
    if (window.historyManager) {
        window.historyManager.closeDeleteModal();
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    window.historyManager = new HistoryManager();
});
